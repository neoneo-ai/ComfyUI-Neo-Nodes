# SPDX-License-Identifier: Apache-2.0
# ComfyUI-Neo-Nodes - Skills (目录式多文件 Markdown 技能)
"""
Skill = 一个目录，内含主文件 skill.md（大小写不敏感：SKILL.md / Skill.md 亦可；YAML frontmatter + 系统提示词正文）+ 可选的其它 *.md 与子目录中的 *.txt 引用文件。

存储布局：
    skills/
      presets/<skill_id>/   预设（随插件发布，只读、不可删）
      tasks/<skill_id>/     任务（内置 LLM 操作，供 llm.LLM_TASKS 使用）
      custom/<skill_id>/    用户自定义

约定：
- skill id = 目录名。
- 元数据只从 skill.md 的 YAML frontmatter 读取（name/tags/inputs/description/
  max_tokens/result_key/multi_result/multi_turn/category/markers/
  gen_image/created_at）。
- 系统提示词 = 顶层所有 .md 按文件名升序拼接（子目录与 *.txt 引用文件不并入，
  由代理按需读取）；带 YAML frontmatter 的 .md（含主文件 skill.md，忽略大小写）
  去掉 frontmatter，其余正文原样保留。

本模块承载 skill 的目录管理与"按需读取引用文件"的代理循环；仅在函数运行时惰性导入 llm 原语，
避免与 llm.py（顶层 from . import skill）形成循环导入。prompts.py / llm.py 作为消费者从这里导入。
"""

from __future__ import annotations

import os
import re
import io
import copy
import json
import math
import base64
import shutil
import logging
import tempfile
import datetime
import threading
import zipfile

import yaml
from aiohttp import web

try:
    from pypinyin import lazy_pinyin, Style as _PinyinStyle
except ImportError:  # pypinyin 缺失时中文拼音匹配静默不可用，其余功能正常
    lazy_pinyin = None
import server
from server import PromptServer

logger = logging.getLogger(__name__)

CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
SKILLS_DIR = os.path.join(CURRENT_DIR, "skills")
SKILL_PRESETS_DIR = os.path.join(SKILLS_DIR, "presets")
SKILL_CUSTOM_DIR = os.path.join(SKILLS_DIR, "custom")
TASKS_DIR = os.path.join(SKILLS_DIR, "tasks")

for _d in (SKILLS_DIR, SKILL_PRESETS_DIR, SKILL_CUSTOM_DIR, TASKS_DIR):
    if not os.path.exists(_d):
        os.makedirs(_d)

_skills_lock = threading.Lock()

# 仅内部使用的任务（实现细节），不对外展示为可选 skill
_SKILL_INTERNAL = {
    "template_prompt",
    "extract_title",
    "extract_classify",
}

# 内置使命级别的默认输入契约（skill.md 未声明 inputs 时使用）
_SKILL_DEFAULT_INPUTS = {
    "reverse_prompt": ["image", "text"],
    "smart_prompt": ["text"],
    "template_prompt": ["text"],
    "translate_prompt": ["text"],
    "extract_title": ["text"],
    "extract_classify": ["text"],
}

# 输入框 @ 标记 -> skill id 路由表（skill.md 未声明 markers 时的兜底）
_SKILL_MARKERS = {
    "reverse_prompt": ["@图", "@反推", "@图片"],
}

# frontmatter 序列化时的字段顺序（未列出的额外字段追加在末尾）
_META_KEY_ORDER = (
    "name", "tags", "inputs", "description", "max_tokens",
    "result_key", "multi_result", "multi_turn", "category", "markers",
    "gen_image", "requires_ref", "created_at",
)

# 技能文件管理器支持的文件扩展名（.md 主/子文档 + .txt 引用文本）。
# 注意：系统提示词拼接仍只取顶层 .md（见 load_skill_content），此集合仅用于文件管理。
_SKILL_FILE_EXTS = (".md", ".txt")


def _skill_category(skill_id: str, data: dict) -> str:
    """推断 skill 分类：vision（含图像输入）/ task（任务）/ style（模板）。"""
    if data.get("category"):
        return data["category"]
    if "image" in (data.get("inputs") or []):
        return "vision"
    return "task"


# ==========================================
# Frontmatter 解析 / 序列化
# ==========================================

def split_frontmatter(text: str) -> tuple[dict, str]:
    """把 skill.md 拆成 (metadata dict, body str)。frontmatter 是文件开头的 --- YAML 块。

    闭合分隔符通过 PyYAML 事件流（第一个 DocumentEndEvent）定位，而不是扫描
    字面量 ``---`` 行，这样多行 YAML 值里即使含有 ``---`` 也能正确解析。
    body 按原始 Markdown 返回，从不按 YAML 解析。
    """
    if text.startswith("\ufeff"):
        text = text[1:]
    if not text.startswith("---"):
        return {}, text
    lines = text.split("\n")
    end_line = None
    for event in yaml.parse(text, Loader=yaml.SafeLoader):
        if isinstance(event, yaml.DocumentEndEvent):
            end_line = event.end_mark.line
            break
    if end_line is None or end_line < 1:
        return {}, text
    fm_text = "\n".join(lines[1:end_line])
    try:
        meta = yaml.safe_load(fm_text)
    except Exception:
        logger.warning(f"Invalid YAML frontmatter:\n{fm_text[:200]}")
        return {}, text
    if not isinstance(meta, dict):
        meta = {}
    body = "\n".join(lines[end_line + 1:]).lstrip("\n")
    return meta, body


def serialize_frontmatter(meta: dict, body: str) -> str:
    """把 metadata + 正文拼回 skill.md 文本。"""
    ordered = {}
    for key in _META_KEY_ORDER:
        if meta.get(key) is not None:
            ordered[key] = meta[key]
    for k, v in meta.items():
        if k not in ordered and v is not None:
            ordered[k] = v
    fm = yaml.safe_dump(ordered, allow_unicode=True, default_flow_style=False, sort_keys=False)
    return f"---\n{fm}---\n\n{body}"


# ==========================================
# 目录 / 内容读取
# ==========================================

def _skill_dir(skill_id: str) -> str | None:
    """返回 skill id 对应的目录（custom > presets > tasks），不存在则 None。"""
    if not skill_id:
        return None
    for base in (SKILL_CUSTOM_DIR, SKILL_PRESETS_DIR, TASKS_DIR):
        d = os.path.join(base, skill_id)
        if os.path.isdir(d):
            return d
    return None


def _skill_source(skill_dir: str) -> str:
    """skill 目录所在分组名（presets/custom/tasks）。"""
    return os.path.basename(os.path.dirname(skill_dir))


def _main_md_name(skill_dir: str) -> str | None:
    """主文件（skill.md，忽略大小写）在目录内的实际文件名；无则 None。

    兼容 SKILL.md / Skill.md 等写法（Agent Skills 常用大写），并在大小写敏感
    的文件系统上也能正确定位到真实文件名。
    """
    try:
        names = [fn for fn in os.listdir(skill_dir)
                 if fn.lower() == "skill.md" and os.path.isfile(os.path.join(skill_dir, fn))]
    except OSError:
        return None
    return sorted(names)[0] if names else None


def _read_skill_md(skill_dir: str) -> tuple[dict, str]:
    main = _main_md_name(skill_dir)
    if not main:
        return {}, ""
    path = os.path.join(skill_dir, main)
    try:
        with open(path, 'r', encoding='utf-8') as f:
            text = f.read()
    except Exception as e:
        logger.warning(f"Error reading {main} in {skill_dir}: {e}")
        return {}, ""
    return split_frontmatter(text)


def _list_all_skill_files(skill_dir: str) -> list[str]:
    """递归列出 skill 目录内所有受支持文件（.md/.txt）的相对路径（/ 分隔）。

    顶层文件在前、其余按路径升序，供前端技能文件管理器展示与编辑。"""
    found = []
    for dirpath, _dirnames, filenames in os.walk(skill_dir):
        for fn in filenames:
            if not fn.lower().endswith(_SKILL_FILE_EXTS):
                continue
            rel = os.path.relpath(os.path.join(dirpath, fn), skill_dir).replace(os.sep, "/")
            found.append(rel)
    found.sort(key=lambda r: (0 if "/" not in r else 1, r.lower()))
    return found


def _main_md_files_for_language(skill_dir: str, language: str) -> list:
    """返回指定语言下应并入系统提示词的顶层 .md 文件（升序）。

    同一 skill 的中英主文件互斥：language='cn' 优先 skill.cn.md，缺省时回退 skill.md；
    language='en'（默认）优先 skill.md，缺省时回退 skill.cn.md。其余顶层 .md 一律保留。
    """
    try:
        names = sorted(fn for fn in os.listdir(skill_dir)
                       if fn.lower().endswith(".md") and os.path.isfile(os.path.join(skill_dir, fn)))
    except OSError:
        return []
    has_cn = any(n.lower() == "skill.cn.md" for n in names)
    has_en = any(n.lower() == "skill.md" for n in names)

    def keep(fn):
        lfn = fn.lower()
        if lfn == "skill.cn.md":
            # EN 语言下，若存在英文主文件则丢弃中文孪生文件
            return not (language != "cn" and has_en)
        if lfn == "skill.md":
            # CN 语言下，若存在中文主文件则丢弃英文孪生文件
            return not (language == "cn" and has_cn)
        return True

    return [fn for fn in names if keep(fn)]


def load_skill_content(skill_id: str, language: str = "en") -> str | None:
    """拼接 skill 目录顶层主 .md（按语言选择，中英互斥）为系统提示词；带 YAML frontmatter 的
    .md（含主文件 skill.md / skill.cn.md，忽略大小写）去掉 frontmatter，其余正文原样保留。
    （子目录与 .txt 引用文件不并入提示词，由代理按需读取。）"""
    d = _skill_dir(skill_id)
    if not d:
        return None
    parts = []
    for fn in _main_md_files_for_language(d, language):
        fp = os.path.join(d, fn)
        try:
            with open(fp, 'r', encoding='utf-8') as f:
                text = f.read()
        except Exception as e:
            logger.warning(f"Error reading {fp}: {e}")
            continue
        meta, stripped = split_frontmatter(text)
        body = stripped if isinstance(meta, dict) and meta else text
        if body.strip():
            parts.append(body.rstrip("\n"))
    content = "\n\n".join(parts)
    return content or None


def _skill_meta(skill_id: str) -> dict:
    d = _skill_dir(skill_id)
    if not d:
        return {}
    meta, _ = _read_skill_md(d)
    return meta


def load_skill_max_tokens(skill_id: str):
    """加载 skill 声明的 max_tokens 覆盖（未声明则 None）。"""
    val = _skill_meta(skill_id).get("max_tokens")
    try:
        return int(val) if val is not None else None
    except (TypeError, ValueError):
        return None


def load_skill_multi_result(skill_id: str):
    """加载 skill 的 multi_result 输出契约（未声明则 None）。"""
    meta = _skill_meta(skill_id)
    return meta.get("multi_result") if meta else None


# ==========================================
# On-demand reference loading (tool-calling agent)
# ==========================================

def list_skill_references(skill_id: str) -> list:
    """返回 skill 内可被代理按需读取的引用文件（相对路径，升序、去重）。

    即除顶层主 .md（skill.md / skill.cn.md）外的所有受支持文件（.md/.txt，含 references/ 子目录）。
    """
    d = _skill_dir(skill_id)
    if not d:
        return []
    refs = []
    for rel in _list_all_skill_files(d):
        base = rel.split("/")[-1].lower()
        is_top = "/" not in rel
        if is_top and (base == "skill.md" or base == "skill.cn.md"):
            continue
        refs.append(rel)
    return refs


def build_reference_index(skill_id: str, language: str = "en") -> str:
    """生成注入系统提示词的引用文件索引；无引用时返回空串。"""
    refs = list_skill_references(skill_id)
    if not refs:
        return ""
    lines = [
        "",
        "## Available reference files",
        "",
        "The skill instructions above refer to on-demand reference files. When you reach a step that says to read one, call the `read_skill_file` tool with its exact relative path from the list below. Load it before using it; do not guess its contents.",
        "",
    ]
    lines.extend(f"- {rel}" for rel in refs)
    return "\n".join(lines)


def read_skill_file(skill_id: str, rel_path: str):
    """代理工具：按相对路径读取 skill 引用文件；越界/不存在/不可读返回 None。"""
    d = _skill_dir(skill_id)
    if not d or not rel_path:
        return None
    target = _safe_skill_file_path(d, rel_path)
    if not target or not os.path.isfile(target):
        return None
    try:
        with open(target, 'r', encoding='utf-8') as f:
            return f.read()
    except Exception as e:
        logger.warning(f"Error reading skill reference {rel_path}: {e}")
        return None


_SKILL_FILE_TOOL = {
    "type": "function",
    "function": {
        "name": "read_skill_file",
        "description": ("Read one reference file of the current skill by its exact relative path "
                        "(e.g. 'references/model-selection.md'). Call it only for files listed in the "
                        "'Available reference files' section, when the skill instructions tell you to read them."),
        "parameters": {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "Relative path of the reference file within the skill directory."},
            },
            "required": ["path"],
        },
    },
}

_REFERENCE_IMAGE_TOOL = {
    "type": "function",
    "function": {
        "name": "get_reference_image",
        "description": ("Fetch the actual pixels of one workflow reference image by its 1-based index in the "
                        "'Reference media' list of <workflow_context>. Call it only when you need to inspect a "
                        "specific reference image's content; do not fetch images you will not use."),
        "parameters": {
            "type": "object",
            "properties": {
                "index": {"type": "integer", "description": "1-based index of the reference image in <workflow_context>."},
            },
            "required": ["index"],
        },
    },
}

_MAX_SKILL_AGENT_TURNS = 8


def _format_workflow_context(context) -> str:
    """把前端采集的工作流上下文（MiniMax H3 参数 + 叶子媒体清单）格式化为系统提示词文本块。

    参考图只列元数据不内联；带尺寸的图片可通过 get_reference_image 工具按需取回像素。
    """
    if not isinstance(context, dict):
        return ""
    h3 = context.get("h3") or []
    refs = context.get("references") or []
    nodes = context.get("nodes") or []
    if not (h3 or refs):
        return ""

    def _ratio(w, h):
        try:
            w, h = int(w), int(h)
            if w <= 0 or h <= 0:
                return ""
            g = math.gcd(w, h)
            rw, rh = w / g, h / g
            fmt = "{:.2f}".format(rw).rstrip("0").rstrip(".") + ":" + "{:.2f}".format(rh).rstrip("0").rstrip(".")
            return f" ({fmt})"
        except (TypeError, ValueError):
            return ""

    def _dur(v):
        try:
            f = float(v)
        except (TypeError, ValueError):
            return ""
        r = round(f)
        return f"{int(r)}s" if abs(f - r) < 0.05 else f"{f:.1f}s"

    def _tag_list(label, files):
        # <Tag N> = 第 N 个该类型参考（1-based，与 tokenizer 计数一致）；files 为按序号排列的文件名（可含 None）
        if not isinstance(files, (list, tuple)) or not files:
            return ""
        parts = []
        for i, f in enumerate(files, 1):
            t = f"<{label} {i}>"
            if f:
                t += " " + str(f)
            parts.append(t)
        return ", ".join(parts)

    def _keyframe_tags(kf):
        # ImageToVideo 的 first/last frame 本身就是 <Picture N>（tokenizer 按 [first, last] 顺序编号）
        entries = []
        if isinstance(kf, dict):
            if "first" in kf:
                entries.append((kf.get("first"), "first frame"))
            if "last" in kf:
                entries.append((kf.get("last"), "last frame"))
        parts = []
        for i, (f, role) in enumerate(entries, 1):
            t = f"<Picture {i}>"
            if f:
                t += " " + str(f)
            parts.append(t + f" ({role})")
        return ", ".join(parts)

    lines = ["<workflow_context>"]
    if h3:
        lines.append("MiniMax H3 nodes in the current workflow:")
        has_ref_tags = False
        for i, n in enumerate(h3[:8], 1):
            parts = [str(n.get("type", "H3"))]
            w, h = n.get("width"), n.get("height")
            aspect = n.get("aspect") or ""
            if not aspect and w and h:
                r = _ratio(w, h)
                aspect = r.strip(" ()") if r else ""
            if aspect:
                parts.append(f"Aspect Ratio: {aspect}")
            dur = n.get("duration_seconds")
            if dur is not None:
                d = _dur(dur)
                if d:
                    parts.append(f"Duration: {d}")
            else:
                length = n.get("length")
                if length is not None:
                    try:
                        sec, frames = _dur(int(length) / 24), int(length)
                    except (TypeError, ValueError):
                        sec = ""
                    if sec:
                        parts.append(f"Duration: {sec} ({frames} frames @24fps)")
            size = n.get("ref_image_size")
            if size:
                parts.append(f"ref_image_size={size}")
            nrefs = n.get("refs") or {}
            if isinstance(nrefs, dict):
                tag_parts = [t for t in (_keyframe_tags(nrefs.get("keyframes")),
                                         _tag_list("Picture", nrefs.get("pictures")),
                                         _tag_list("Video", nrefs.get("videos")),
                                         _tag_list("Audio", nrefs.get("audios"))) if t]
                if tag_parts:
                    parts.append("References: " + ", ".join(tag_parts))
                    has_ref_tags = True
            lines.append(f"  {i}. " + ", ".join(parts))
        if has_ref_tags:
            lines.append("In your prompt, refer to each node's reference media using the <Picture N>/<Video N>/<Audio N> tags listed above.")
    if refs:
        lines.append("Reference media (leaf inputs of the workflow):")
        for i, r in enumerate(refs[:32], 1):
            kind = r.get("kind", "?")
            src = r.get("source") or {}
            name = src.get("value", "") if isinstance(src, dict) else str(src)
            w, h = r.get("width"), r.get("height")
            if w and h:
                lines.append(f"  [{i}] image {name}{_ratio(w, h)} ({w}x{h}) - fetchable via get_reference_image({i})")
            else:
                lines.append(f"  [{i}] {kind} {name}")
        if any(r.get("kind") == "image" for r in refs[:32]):
            lines.append("Fetch a reference image's actual pixels with the get_reference_image tool only when you need to inspect it; do not assume unseen details.")
    others = [t for t in nodes if "MiniMax" not in str(t)][:40]
    if others:
        lines.append("Other node types: " + ", ".join(str(t) for t in others))
    lines.append("</workflow_context>")
    return "\n".join(lines)


def _fetch_reference_image(context, index) -> tuple[bytes | None, str]:
    """按 1-based 序号取回参考图字节（复用 prompts._read_image_raw 的目录校验）。"""
    refs = (context or {}).get("references") or []
    try:
        i = int(index)
    except (TypeError, ValueError):
        return None, f"[error] invalid reference index: {index}"
    if not (1 <= i <= len(refs)):
        return None, f"[error] reference index out of range: {i} (1-{len(refs)})"
    ref = refs[i - 1]
    src = ref.get("source") or {}
    name = src.get("value", "") if isinstance(src, dict) else str(src)
    if ref.get("kind") != "image":
        return None, f"[error] reference {i} ({name}) is a video; only images can be fetched"
    from .prompts import _read_image_raw
    data = _read_image_raw(src) if isinstance(src, dict) else None
    if data is None:
        return None, f"[error] failed to read reference image {i} ({name})"
    return data, f"Reference image {i}: {name}"


def _resolve_skill_language(text: str) -> str:
    """确定加载哪一版主文件：全局偏好 en/cn 优先，否则按输入语言自动判断。"""
    from .llm import _load_remote_config, _detect_language
    try:
        pref = str(_load_remote_config().get("skill_language", "auto")).lower()
    except Exception:
        pref = "auto"
    if pref in ("en", "cn"):
        return pref
    return "cn" if _detect_language(text or "") == "Chinese" else "en"


def _initial_user_message(text: str, images) -> Dict[str, Any]:
    """构造首个 user 消息；有图时组装多模态内容，否则纯文本。"""
    if not images:
        return {"role": "user", "content": text}
    parts = []
    for img_bytes in images:
        b64 = base64.b64encode(img_bytes).decode("utf-8")
        parts.append({"type": "image_url", "image_url": {"url": f"data:image/png;base64,{b64}"}})
    parts.append({"type": "text", "text": text})
    return {"role": "user", "content": parts}


def _skill_agent_core(skill_id: str, text: str, images=None, context=None, enable_thinking=None) -> str:
    """执行 skill 生成：工作流上下文始终注入系统提示词；仅当存在引用文件或参考图像时启用工具调用
    代理循环（本地/远程一致），否则单轮推理。read_skill_file 按需读取引用文件，get_reference_image
    按需取回参考图像素。context 为前端采集的工作流上下文（MiniMax H3 参数 + 参考媒体清单）。
    返回最终答案字符串；失败抛出异常。"""
    from .llm import chat_turn, get_current_mode, LLM_MODE_REMOTE, _run_llm_inference

    skill_id = (skill_id or "").strip()
    if not skill_id:
        raise ValueError("No skill specified")

    language = _resolve_skill_language(text)
    system_prompt = load_skill_content(skill_id, language=language)
    if not system_prompt:
        raise ValueError(f"Skill '{skill_id}' not found or has no content")

    ctx_block = _format_workflow_context(context)
    refs = list_skill_references(skill_id)
    ref_images = [r for r in (context or {}).get("references", []) if r.get("kind") == "image"] if isinstance(context, dict) else []
    max_tokens = load_skill_max_tokens(skill_id) or 500
    remote_mode = (get_current_mode() == LLM_MODE_REMOTE)

    # 系统提示词：主文件 + 引用索引（若有）+ 工作流上下文（若有），单轮与工具循环两条路径共用
    system = system_prompt
    if refs:
        system += "\n" + build_reference_index(skill_id, language)
    if ctx_block:
        system += ("\n\n" if refs else "\n") + ctx_block

    # 无引用文件且无可取回参考图像：单轮生成（系统提示词已含工作流上下文）
    if not (refs or ref_images):
        result = _run_llm_inference(system, text, max_tokens, images=images or None, use_remote=remote_mode, enable_thinking=enable_thinking)
        return result or ""

    # 有引用文件/参考图像：工具调用代理循环（按需取回）
    tools = [_SKILL_FILE_TOOL] if refs else []
    if ref_images:
        tools.append(_REFERENCE_IMAGE_TOOL)
    messages = [
        {"role": "system", "content": system},
        _initial_user_message(text, images),
    ]
    content = ""
    for _ in range(_MAX_SKILL_AGENT_TURNS):
        msg = chat_turn(messages, max_tokens=max_tokens, tools=tools or None, enable_thinking=enable_thinking)
        content = msg.get("content") or ""
        tool_calls = msg.get("tool_calls") or []
        assistant_msg = {"role": "assistant", "content": content}
        if tool_calls:
            assistant_msg["tool_calls"] = tool_calls
        messages.append(assistant_msg)
        if not tool_calls:
            break
        fetched_images = []
        for tc in tool_calls:
            fn = tc.get("function") or {}
            name = fn.get("name")
            try:
                args = json.loads(fn.get("arguments") or "{}")
            except (ValueError, TypeError):
                args = {}
            if name == "read_skill_file":
                file_content = read_skill_file(skill_id, str(args.get("path", "")))
                tool_result = file_content if file_content is not None else f"[error] reference file not found: {args.get('path')}"
            elif name == "get_reference_image":
                img_bytes, caption = _fetch_reference_image(context, args.get("index"))
                tool_result = caption
                if img_bytes is not None:
                    fetched_images.append((caption, img_bytes))
            else:
                tool_result = f"[error] unknown tool: {name}"
            messages.append({"role": "tool", "tool_call_id": tc.get("id", ""), "content": tool_result})
        # 取回的参考图作为独立 user 消息回灌（部分 provider 的 tool 消息不支持图片；
        # 且须在本轮全部 tool 结果之后，保持 assistant->tool*->user 的消息顺序）
        for caption, img_bytes in fetched_images:
            b64 = base64.b64encode(img_bytes).decode("utf-8")
            messages.append({"role": "user", "content": [
                {"type": "text", "text": f"Fetched {caption}."},
                {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{b64}"}},
            ]})

    if not content.strip():
        raise RuntimeError(f"Skill '{skill_id}' produced no output")
    return content


def run_skill_agent(skill_id: str, text: str, images=None, context=None) -> str:
    """非流式执行 skill，返回最终答案字符串；失败抛出异常。"""
    return _skill_agent_core(skill_id, text, images, context)


def _skill_agent_core_stream(skill_id: str, text: str, images=None, context=None, enable_thinking=None) -> Generator[dict, None, None]:
    """流式执行 skill 生成：工作流上下文始终注入系统提示词；单轮路径逐 token 透传 LLM 输出（与
    llm.run_llm_task_stream 一致），仅当存在引用文件或参考图像时走工具循环（复用非流式核心再逐字
    输出）。失败抛出异常，由调用方捕获。"""
    from .llm import get_current_mode, LLM_MODE_REMOTE, _run_llm_inference

    skill_id = (skill_id or "").strip()
    if not skill_id:
        raise ValueError("No skill specified")

    language = _resolve_skill_language(text)
    system_prompt = load_skill_content(skill_id, language=language)
    if not system_prompt:
        raise ValueError(f"Skill '{skill_id}' not found or has no content")

    ctx_block = _format_workflow_context(context)
    refs = list_skill_references(skill_id)
    ref_images = [r for r in (context or {}).get("references", []) if r.get("kind") == "image"] if isinstance(context, dict) else []
    max_tokens = load_skill_max_tokens(skill_id) or 500
    remote_mode = (get_current_mode() == LLM_MODE_REMOTE)

    system = system_prompt
    if refs:
        system += "\n" + build_reference_index(skill_id, language)
    if ctx_block:
        system += ("\n\n" if refs else "\n") + ctx_block

    # 无引用文件/参考图像：单轮生成，逐 token 透传 LLM 输出（系统提示词已含工作流上下文）。
    # 归一成 {"text","kind"}（与 llm.run_llm_task_stream 一致）：思考（thinking）与正文（content）分开打标，
    # 前端据此展示/清除临时思考面板，消费方只累计正文。
    if not (refs or ref_images):
        result = _run_llm_inference(system, text, max_tokens, images=images or None,
                                    use_remote=remote_mode, stream=True, enable_thinking=enable_thinking)
        if hasattr(result, '__iter__') and not isinstance(result, str):
            for chunk in result:
                # 远程生成器已带 {"text","kind"}；本地 llama.cpp 为 {choices:[{delta:{...}}]}。统一归一打标。
                if isinstance(chunk, dict):
                    if "text" in chunk:
                        yield {"text": chunk["text"], "kind": chunk.get("kind", "content")}
                        continue
                    choices = chunk.get("choices", [])
                    if not choices:
                        continue
                    delta = choices[0].get("delta", {})
                    content = delta.get("content") or ""
                    reasoning = delta.get("reasoning_content") or ""
                    if content:
                        yield {"text": content, "kind": "content"}
                    if reasoning:
                        yield {"text": reasoning, "kind": "thinking"}
                elif isinstance(chunk, str):
                    yield {"text": chunk, "kind": "content"}
        else:
            # 本地路径未返回生成器（不支持流式）：回退为整段输出
            yield {"text": result or "", "kind": "content"}
        return

    # 有引用文件/参考图像：工具调用循环需完整消息解析 tool_calls，复用非流式核心后逐字输出（仅正文）
    for ch in _skill_agent_core(skill_id, text, images, context, enable_thinking=enable_thinking):
        yield {"text": ch, "kind": "content"}


def run_skill_agent_stream(skill_id: str, text: str, images=None, context=None, enable_thinking=None) -> Generator[dict, None, None]:
    """流式契约：逐 token yield {"text","kind"}（思考 thinking / 正文 content，与 llm.run_llm_task_stream 一致）；失败 yield [ERROR]。"""
    try:
        saw_content = False
        for chunk in _skill_agent_core_stream(skill_id, text, images, context, enable_thinking=enable_thinking):
            if chunk.get("kind") == "content" and (chunk.get("text") or "").strip():
                saw_content = True
            yield chunk
        # 思考模型可能把 max_tokens 预算全花在 reasoning 上，导致正文为空。
        # 此时给一条可见提示，避免前端在思考结束后静默无响应（最终只保留正文）。
        if not saw_content:
            yield {"text": "[未生成最终提示词：模型思考占用了全部 token 预算。请在 ✨ 菜单勾选「关闭思考」，或调大该技能的 max_tokens 后重试。]", "kind": "content"}
    except Exception as e:
        logger.error(f"Skill agent error for '{skill_id}': {e}")
        yield {"text": f"[ERROR] {str(e)}", "kind": "content"}


def load_task_template(task_name: str) -> dict:
    """读取任务 skill（tasks/<task_name>/skill.md）为 llm.LLM_TASKS 条目。"""
    d = os.path.join(TASKS_DIR, task_name)
    if not os.path.isdir(d):
        return {}
    meta, body = _read_skill_md(d)
    return {
        "content": body,
        "max_tokens": meta.get("max_tokens", 500),
        "result_key": meta.get("result_key", "prompt"),
        "description": meta.get("description", ""),
        "multi_result": meta.get("multi_result"),
    }


def _skill_name_pinyin_tags(name) -> list:
    """为中文技能名生成拼音匹配标签（全拼 + 首字母缩写），供前端 / 菜单按拼音检索。

    仅当名称含 CJK 且安装了 pypinyin 时返回非空；英文/数字字符原样并入拼音串。"""
    if not name or lazy_pinyin is None:
        return []
    s = str(name)
    if not any("\u4e00" <= ch <= "\u9fff" for ch in s):
        return []

    def compact(style):
        return re.sub(r"[^a-z0-9]", "", "".join(lazy_pinyin(s, style=style)).lower())

    tags = []
    full = compact(_PinyinStyle.NORMAL)
    initials = compact(_PinyinStyle.FIRST_LETTER)
    if full:
        tags.append(full)
    if initials and initials != full:
        tags.append(initials)
    return tags


def scan_skills() -> list:
    """合并 tasks + presets/custom 为统一 skill 元数据列表。

    每个 skill 返回: {id, name, category, source, inputs, needs_image, markers, multi_turn, tags, description}
    """
    skills = []

    # 1) 任务 (tasks/<id>/) -> category=task/vision
    if os.path.isdir(TASKS_DIR):
        for entry in sorted(os.listdir(TASKS_DIR)):
            d = os.path.join(TASKS_DIR, entry)
            if not os.path.isdir(d):
                continue
            skill_id = entry
            if skill_id in _SKILL_INTERNAL:
                continue
            meta, _ = _read_skill_md(d)
            inputs = meta.get("inputs") or _SKILL_DEFAULT_INPUTS.get(skill_id, ["text"])
            skills.append({
                "id": skill_id,
                "name": meta.get("name", skill_id),
                "category": _skill_category(skill_id, {**meta, "inputs": inputs}),
                "source": "tasks",
                "tags": list(meta.get("tags", [])) + _skill_name_pinyin_tags(meta.get("name", skill_id)),
                "inputs": inputs,
                "needs_image": "image" in inputs,
                "markers": meta.get("markers") or _SKILL_MARKERS.get(skill_id, []),
                "multi_turn": bool(meta.get("multi_turn", False)),
                "gen_image": bool(meta.get("gen_image", False)),
                "requires_ref": bool(meta.get("requires_ref", False)),
                "description": meta.get("description", ""),
            })

    # 2) 预设 + 自定义 (presets/<id>/, custom/<id>/) -> category=frontmatter（缺省 image_enhance）
    with _skills_lock:
        for base, source in ((SKILL_PRESETS_DIR, "presets"), (SKILL_CUSTOM_DIR, "custom")):
            if not os.path.isdir(base):
                continue
            for entry in sorted(os.listdir(base)):
                d = os.path.join(base, entry)
                if not os.path.isdir(d):
                    continue
                skill_id = entry
                meta, _ = _read_skill_md(d)
                inputs = meta.get("inputs") or ["text"]
                skills.append({
                    "id": skill_id,
                    "name": meta.get("name", skill_id),
                    "category": meta.get("category", "image_enhance"),
                    "source": source,
                    "tags": list(meta.get("tags", [])) + _skill_name_pinyin_tags(meta.get("name", skill_id)),
                    "inputs": inputs,
                    "needs_image": "image" in inputs,
                    "markers": meta.get("markers") or [],
                    "multi_turn": bool(meta.get("multi_turn", False)),
                    "gen_image": bool(meta.get("gen_image", False)),
                    "requires_ref": bool(meta.get("requires_ref", False)),
                    "description": meta.get("description", ""),
                })

    return skills


# ==========================================
# 文件管理 / 保存（含路径安全校验）
# ==========================================

def _normalize_skill_id(raw: str) -> str:
    """规范化 skill id：目录名，仅保留 [A-Za-z0-9_-]。"""
    raw = (raw or "").strip()
    raw = raw.replace("\\", "/").split("/")[-1]
    return re.sub(r'[^A-Za-z0-9_-]', '', raw)


def _safe_skill_file_path(skill_dir: str, filename: str) -> str | None:
    """校验并返回 skill 目录内受支持文件（.md/.txt，可含子目录）的绝对路径；
    非法/越界/非受支持类型返回 None。"""
    fn = (filename or "").replace("\\", "/").strip()
    if not fn or fn.startswith("/"):
        return None
    parts = [p for p in fn.split("/") if p not in ("", ".")]
    if not parts or any(p == ".." for p in parts):
        return None
    if not parts[-1].lower().endswith(_SKILL_FILE_EXTS):
        return None
    target = os.path.realpath(os.path.join(skill_dir, *parts))
    base = os.path.realpath(skill_dir)
    if os.path.commonpath([target, base]) != base:
        return None
    return target


def _find_name_conflict(name: str, exclude_id: str):
    """返回与 name 同名但 id 不同的 skill 的 id；无冲突返回 None。"""
    target = (name or "").strip()
    if not target:
        return None
    for s in scan_skills():
        if s["id"] != exclude_id and (s.get("name") or "").strip() == target:
            return s["id"]
    return None


def save_skill_main(skill_id: str, name: str, content: str, tags=None, source: str = "custom", multi_turn=None,
                    category=None, gen_image=None, requires_ref=None) -> bool:
    """保存 skill 的主文件 skill.md（frontmatter + 正文），保留未编辑的既有字段。

    multi_turn/category/gen_image/requires_ref 为 None 时沿用 frontmatter 既有值；显式传入则写入（假值时移除该字段）。
    """
    sid = _normalize_skill_id(skill_id)
    if not sid:
        return False
    base = SKILL_PRESETS_DIR if source == "presets" else SKILL_CUSTOM_DIR
    d = os.path.join(base, sid)
    with _skills_lock:
        os.makedirs(d, exist_ok=True)
        meta, _body = _read_skill_md(d)
        mt = meta.get("multi_turn") if multi_turn is None else bool(multi_turn)
        cat = meta.get("category") if category is None else (category or "").strip()
        gi = meta.get("gen_image") if gen_image is None else bool(gen_image)
        rr = meta.get("requires_ref") if requires_ref is None else bool(requires_ref)
        new_meta = {
            "name": (name or "").strip() or sid,
            "tags": list(tags or []),
            "description": meta.get("description", ""),
            "inputs": meta.get("inputs"),
            "max_tokens": meta.get("max_tokens"),
            "result_key": meta.get("result_key"),
            "multi_result": meta.get("multi_result"),
            "multi_turn": mt or None,
            "category": cat or None,
            "markers": meta.get("markers"),
            "gen_image": gi or None,
            "requires_ref": rr or None,
            "ratio": meta.get("ratio"),
            "created_at": meta.get("created_at") or datetime.datetime.now(datetime.timezone.utc).isoformat(),
        }
        new_meta = {k: v for k, v in new_meta.items() if v is not None}
        text = serialize_frontmatter(new_meta, content or "")
        main = _main_md_name(d) or "skill.md"
        with open(os.path.join(d, main), 'w', encoding='utf-8', newline='\n') as f:
            f.write(text)
    return True


def save_skill_file(skill_id: str, filename: str, content: str) -> bool:
    """保存 skill 目录内的某个 .md 文件。"""
    d = _skill_dir(skill_id)
    if not d:
        return False
    target = _safe_skill_file_path(d, filename)
    if not target:
        return False
    with _skills_lock:
        try:
            os.makedirs(os.path.dirname(target), exist_ok=True)
            with open(target, 'w', encoding='utf-8', newline='\n') as f:
                f.write(content or "")
        except Exception as e:
            logger.error(f"Error saving skill file {target}: {e}")
            return False
    return True


def delete_skill_file(skill_id: str, filename: str) -> bool:
    """删除 skill 目录内某个 .md 文件（不允许删 skill.md）。"""
    d = _skill_dir(skill_id)
    if not d:
        return False
    fn = (filename or "").replace("\\", "/")
    if fn.lower() == "skill.md":
        return False
    target = _safe_skill_file_path(d, fn)
    if not target or not os.path.isfile(target):
        return False
    with _skills_lock:
        os.remove(target)
    return True


def delete_skill(skill_id: str) -> tuple[bool, str]:
    """删除整个 skill 目录。预设不可删。返回 (success, message)。"""
    sid = _normalize_skill_id(skill_id)
    if not sid:
        return False, "Invalid skill id"
    with _skills_lock:
        for base in (SKILL_CUSTOM_DIR, SKILL_PRESETS_DIR):
            d = os.path.join(base, sid)
            if os.path.isdir(d):
                if os.path.basename(base) == "presets":
                    return False, "Cannot delete preset skill"
                shutil.rmtree(d)
                return True, "deleted"
    return False, "Skill not found"


# ==========================================
# 生图技能：工作流模板导出 / 每技能 config.json
# ==========================================

def load_skill_workflow(skill_id: str):
    """读 skill 的 workflow.json（API prompt 模板）；缺失或非法返回 None。"""
    d = _skill_dir(str(skill_id or ""))
    if not d:
        return None
    try:
        with open(os.path.join(d, "workflow.json"), encoding="utf-8") as f:
            wf = json.load(f)
    except Exception:
        return None
    return wf if isinstance(wf, dict) and wf else None


def get_skill_gen_config(skill_id: str) -> dict:
    """读 skill 的 config.json（生图设置覆盖）；缺失或损坏返回 {}。"""
    d = _skill_dir(str(skill_id or ""))
    if not d:
        return {}
    try:
        with open(os.path.join(d, "config.json"), encoding="utf-8") as f:
            cfg = json.load(f)
    except Exception:
        return {}
    return cfg if isinstance(cfg, dict) else {}


def save_skill_gen_config(skill_id: str, cfg: dict) -> tuple[bool, str]:
    """写 skill 的 config.json（预设只读）。返回 (success, message)。"""
    sid = _normalize_skill_id(str(skill_id or ""))
    d = _skill_dir(sid) if sid else None
    if not d:
        return False, "Skill not found"
    if _skill_source(d) == "presets":
        return False, "Cannot modify preset skill"
    cfg = cfg if isinstance(cfg, dict) else {}
    clean = {}
    for key in ("model", "text_encoder", "vae"):
        value = str(cfg.get(key) or "").strip()
        if value:
            clean[key] = value[:256]
    loras = []
    for entry in cfg.get("loras") or []:
        name = str((entry or {}).get("name") or "").strip() if isinstance(entry, dict) else str(entry or "").strip()
        if not name:
            continue
        try:
            strength = float((entry or {}).get("strength", 1.0))
        except (TypeError, ValueError):
            strength = 1.0
        loras.append({"name": name[:256], "strength": max(-10.0, min(10.0, strength)),
                      "ref_only": bool((entry or {}).get("ref_only"))})
    clean["loras"] = loras
    for key in ("base_resolution", "count"):
        try:
            clean[key] = max(1, int(cfg.get(key)))
        except (TypeError, ValueError):
            continue
    ratio = str(cfg.get("default_ratio") or "").strip()
    if ratio:
        clean["default_ratio"] = ratio[:32]
    prefix = str(cfg.get("output_prefix") or "").strip()
    if prefix:
        clean["output_prefix"] = prefix[:128]
    if cfg.get("enhance_prompt"):
        clean["enhance_prompt"] = True
    with _skills_lock:
        tmp = os.path.join(d, "config.json.tmp")
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(clean, f, indent=2, ensure_ascii=False)
        os.replace(tmp, os.path.join(d, "config.json"))
    return True, ""


def _node_sort_key(nid):
    try:
        return (0, int(str(nid)), "")
    except (TypeError, ValueError):
        return (1, 0, str(nid))


def _model_consumer(workflow: dict, src_id: str):
    """model 输入连到 src 输出的 LoraLoaderModelOnly 节点 id；无则 None。"""
    best = None
    for nid, node in workflow.items():
        if not isinstance(node, dict) or node.get("class_type") != "LoraLoaderModelOnly":
            continue
        v = (node.get("inputs") or {}).get("model")
        if isinstance(v, list) and len(v) == 2 and v[0] == str(src_id):
            if best is None or _node_sort_key(nid) < _node_sort_key(best):
                best = nid
    return best


def _reaches_load_image(workflow: dict, node_id: str) -> bool:
    """节点输入链路（沿所有连线回溯）是否到达 LoadImage；用于识别参考图缩放节点。"""
    stack, seen = [str(node_id)], set()
    while stack:
        nid = stack.pop()
        if nid in seen:
            continue
        seen.add(nid)
        node = workflow.get(nid)
        if not isinstance(node, dict):
            continue
        if node.get("class_type") == "LoadImage":
            return True
        for v in (node.get("inputs") or {}).values():
            if isinstance(v, list) and len(v) == 2 and isinstance(v[0], str):
                stack.append(v[0])
    return False


_COMMON_RATIOS = (("1:1", 1.0), ("16:9", 16 / 9), ("9:16", 9 / 16),
                  ("4:3", 4 / 3), ("3:4", 3 / 4), ("3:2", 3 / 2), ("2:3", 2 / 3))


def _ratio_label(w: int, h: int) -> str:
    if w <= 0 or h <= 0:
        return ""
    value = w / h
    for label, target in _COMMON_RATIOS:
        if abs(value - target) < 0.01:
            return label
    return f"{w}:{h}"


def _template_from_workflow(workflow: dict) -> tuple[dict, list, dict]:
    """把 API prompt 转成模板：已知值替换为占位符、主链 LoRA 编为 {{LORA_i_*}} 槽位。

    返回 (template, warnings, seed_cfg)；seed_cfg 是从加载器/LoRA/latent 尺寸/SaveImage
    前缀提取的 config.json 初值（只含非空项）。"""
    template = copy.deepcopy(workflow)
    warnings = []
    seed_cfg = {}

    clip_nodes = [nid for nid, n in workflow.items()
                  if isinstance(n, dict) and n.get("class_type") == "CLIPTextEncode"]
    if not clip_nodes:
        warnings.append("工作流没有 CLIPTextEncode 节点，运行时无法注入提示词")
    for i, nid in enumerate(clip_nodes):
        inputs = template[nid]["inputs"]
        if isinstance(inputs.get("text"), str):
            inputs["text"] = "{{PROMPT}}" if i == 0 else "{{NEGATIVE}}"

    for nid, node in workflow.items():
        ct = node.get("class_type")
        inputs = template[nid]["inputs"]
        if ct == "UNETLoader" and isinstance(inputs.get("unet_name"), str):
            seed_cfg.setdefault("model", inputs["unet_name"])
            inputs["unet_name"] = "{{MODEL}}"
        elif ct == "CLIPLoader" and isinstance(inputs.get("clip_name"), str):
            seed_cfg.setdefault("text_encoder", inputs["clip_name"])
            inputs["clip_name"] = "{{TEXT_ENCODER}}"
        elif ct == "VAELoader" and isinstance(inputs.get("vae_name"), str):
            seed_cfg.setdefault("vae", inputs["vae_name"])
            inputs["vae_name"] = "{{VAE}}"
        elif ct in ("KSampler", "KSamplerAdvanced") and "seed" in inputs:
            inputs["seed"] = "{{SEED}}"
        elif ct in ("EmptyLatentImage", "EmptySD3LatentImage"):
            if isinstance(inputs.get("width"), int) and isinstance(inputs.get("height"), int):
                seed_cfg.setdefault("default_ratio", _ratio_label(inputs["width"], inputs["height"]))
            for key, token in (("width", "{{WIDTH}}"), ("height", "{{HEIGHT}}"), ("batch_size", "{{COUNT}}")):
                if isinstance(inputs.get(key), int):
                    inputs[key] = token
        elif ct == "SaveImage" and isinstance(inputs.get("filename_prefix"), str):
            seed_cfg.setdefault("output_prefix", inputs["filename_prefix"])
            inputs["filename_prefix"] = "{{PREFIX}}"
        elif ct == "LoadImage" and isinstance(inputs.get("image"), str):
            inputs["image"] = "{{REF_IMAGE}}"

    if not any(isinstance(n, dict) and n.get("class_type") == "SaveImage" for n in workflow.values()):
        warnings.append("工作流没有 SaveImage 节点，将无法收集输出图片")

    # 主链 LoRA：UNETLoader → LoraLoaderModelOnly* 链按序编号为槽位
    loras = []
    slot = 0
    unet_ids = sorted((nid for nid, n in workflow.items()
                       if isinstance(n, dict) and n.get("class_type") == "UNETLoader"),
                      key=_node_sort_key)
    for unet_id in unet_ids:
        cur = unet_id
        while True:
            nxt = _model_consumer(workflow, cur)
            if not nxt:
                break
            slot += 1
            orig = workflow[nxt]["inputs"]
            try:
                strength = float(orig.get("strength_model", 1.0))
            except (TypeError, ValueError):
                strength = 1.0
            loras.append({"name": str(orig.get("lora_name") or ""), "strength": strength})
            template[nxt]["inputs"]["lora_name"] = "{{LORA_%d_NAME}}" % slot
            template[nxt]["inputs"]["strength_model"] = "{{LORA_%d_STRENGTH}}" % slot
            cur = nxt
    if loras:
        seed_cfg["loras"] = [l for l in loras if l["name"]]

    return template, warnings, seed_cfg


def save_workflow_skill(name: str, description: str, tags, workflow: dict) -> dict:
    """把当前画布工作流（API prompt）导出为生图技能：skill.md + workflow.json + config.json。"""
    if not isinstance(workflow, dict) or not workflow:
        return {"success": False, "message": "workflow 不是合法的 API prompt"}
    for nid, node in workflow.items():
        if not isinstance(node, dict) or not node.get("class_type") or not isinstance(node.get("inputs"), dict):
            return {"success": False, "message": f"节点 {nid} 缺少 class_type/inputs"}
    template, warnings, seed_cfg = _template_from_workflow(workflow)
    has_ref = any(isinstance(v, str) and "{{REF_IMAGE}}" in v
                  for n in template.values() if isinstance(n, dict)
                  for v in (n.get("inputs") or {}).values())

    base_id = _normalize_skill_id(str(name or "")) or "workflow-skill"
    sid, i = base_id, 2
    while os.path.isdir(os.path.join(SKILL_CUSTOM_DIR, sid)):
        sid = f"{base_id}-{i}"
        i += 1
    meta = {
        "name": str(name or "").strip() or sid,
        "tags": [str(t) for t in (tags if isinstance(tags, list) else [])],
        "description": str(description or ""),
        "inputs": ["text"],
        "category": "image_gen",
        "gen_image": True,
    }
    if has_ref:
        meta["requires_ref"] = True
    with _skills_lock:
        d = os.path.join(SKILL_CUSTOM_DIR, sid)
        os.makedirs(d, exist_ok=True)
        tmp = os.path.join(d, "skill.md.tmp")
        with open(tmp, "w", encoding="utf-8") as f:
            f.write(serialize_frontmatter(meta, str(description or "")))
        os.replace(tmp, os.path.join(d, "skill.md"))
        tmp = os.path.join(d, "workflow.json.tmp")
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(template, f, indent=2, ensure_ascii=False)
        os.replace(tmp, os.path.join(d, "workflow.json"))
        if seed_cfg:
            tmp = os.path.join(d, "config.json.tmp")
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(seed_cfg, f, indent=2, ensure_ascii=False)
            os.replace(tmp, os.path.join(d, "config.json"))
    return {"success": True, "id": sid, "warnings": warnings}


def copy_skill_files(from_id: str, to_id: str) -> tuple[bool, str]:
    """把 from 技能的 workflow.json / config.json 复制到 to（供「复制为自定义」补全生图模板）。"""
    src = _skill_dir(str(from_id or ""))
    dst = _skill_dir(str(to_id or ""))
    if not src or not dst:
        return False, "Skill not found"
    copied = 0
    with _skills_lock:
        for fn in ("workflow.json", "config.json"):
            s = os.path.join(src, fn)
            if os.path.isfile(s):
                shutil.copy2(s, os.path.join(dst, fn))
                copied += 1
    return True, f"copied {copied} file(s)"


# ==========================================
# 上传（zip / 目录清单）
# ==========================================

def _write_skill_files(target_dir: str, rel_paths: list[str], blobs: list[bytes]) -> bool:
    """把 (相对路径, 内容) 写入 target_dir，仅保留受支持文件（.md/.txt）并校验安全；缺 skill.md 时自动创建。"""
    os.makedirs(target_dir, exist_ok=True)
    base = os.path.realpath(target_dir)
    wrote_skill_md = False
    for rel, blob in zip(rel_paths, blobs):
        parts = [p for p in (rel or "").replace("\\", "/").split("/") if p not in ("", ".")]
        if not parts or any(p == ".." for p in parts):
            logger.warning(f"Reject unsafe skill file path: {rel}")
            continue
        if not parts[-1].lower().endswith(_SKILL_FILE_EXTS):
            continue
        target = os.path.realpath(os.path.join(base, *parts))
        if os.path.commonpath([target, base]) != base:
            logger.warning(f"Reject out-of-bounds skill file path: {rel}")
            continue
        os.makedirs(os.path.dirname(target), exist_ok=True)
        with open(target, 'wb') as f:
            f.write(blob or b"")
        if parts[-1].lower() == "skill.md":
            wrote_skill_md = True
    if not wrote_skill_md:
        # 自动创建 skill.md（带最小 frontmatter），保证目录是合法 skill
        with open(os.path.join(base, "skill.md"), 'w', encoding='utf-8', newline='\n') as f:
            f.write(serialize_frontmatter({"name": os.path.basename(base)}, ""))
    return True


def _collect_skill_files(root: str) -> tuple[list[str], list[bytes]]:
    """收集 root 下所有受支持文件（.md/.txt）的 (相对路径, 字节)。"""
    rel_paths = []
    blobs = []
    for dirpath, _dirnames, filenames in os.walk(root):
        for fn in sorted(filenames):
            if not fn.lower().endswith(_SKILL_FILE_EXTS):
                continue
            full = os.path.join(dirpath, fn)
            rel = os.path.relpath(full, root).replace("\\", "/")
            with open(full, "rb") as f:
                blobs.append(f.read())
            rel_paths.append(rel)
    return rel_paths, blobs


def _upload_from_zip(zip_bytes: bytes, skill_id_field: str) -> dict:
    tmpdir = tempfile.mkdtemp(prefix="skill_zip_")
    try:
        with zipfile.ZipFile(io.BytesIO(zip_bytes)) as zf:
            for info in zf.infolist():
                name = info.filename.replace("\\", "/")
                parts = [p for p in name.split("/") if p not in ("", ".")]
                if os.path.isabs(name) or any(p == ".." for p in parts):
                    return {"success": False, "status": 400, "message": f"Unsafe path in zip: {name}"}
            zf.extractall(tmpdir)

        entries = [e for e in os.listdir(tmpdir) if not e.startswith("__MACOSX") and not e.startswith(".")]
        root = tmpdir
        wrapper_id = ""
        if len(entries) == 1 and os.path.isdir(os.path.join(tmpdir, entries[0])):
            root = os.path.join(tmpdir, entries[0])
            wrapper_id = entries[0]

        sid = _normalize_skill_id(skill_id_field or wrapper_id)
        if not sid:
            return {"success": False, "status": 400, "message": "skill_id required (no wrapper folder in zip)"}

        rel_paths, blobs = _collect_skill_files(root)
        _write_skill_files(os.path.join(SKILL_CUSTOM_DIR, sid), rel_paths, blobs)
        return {"success": True, "id": sid}
    except Exception as e:
        logger.error(f"Error extracting skill zip: {e}")
        return {"success": False, "status": 500, "message": str(e)}
    finally:
        shutil.rmtree(tmpdir, ignore_errors=True)


def _upload_from_manifest(rel_paths: list[str], file_parts: list[tuple[str, bytes]], skill_id_field: str) -> dict:
    if not rel_paths:
        return {"success": False, "status": 400, "message": "Empty manifest"}
    norm = [p.replace("\\", "/") for p in rel_paths]
    # 若所有路径共享同一顶层目录，视为选中的 skill 根文件夹（webkitRelativePath 首段）
    tops = {n.split("/", 1)[0] for n in norm if "/" in n}
    strip_top = len(tops) == 1 and all("/" in n for n in norm)
    inner = [n.split("/", 1)[1] if strip_top else n for n in norm]
    sid = _normalize_skill_id(skill_id_field or (list(tops)[0] if strip_top else ""))
    if not sid:
        return {"success": False, "status": 400, "message": "skill_id required"}

    paths = []
    blobs = []
    for rel, (_fname, blob) in zip(inner, file_parts):
        if rel.lower().endswith(_SKILL_FILE_EXTS):
            paths.append(rel)
            blobs.append(blob)
    _write_skill_files(os.path.join(SKILL_CUSTOM_DIR, sid), paths, blobs)
    return {"success": True, "id": sid}


# ==========================================
# API Routes (skill 管理)
# ==========================================

@server.PromptServer.instance.routes.get("/rs_prompts/skills")
async def rs_prompts_list_skills(request):
    """列出所有 skill（任务 + 预设/自定义统一元数据）。"""
    try:
        return web.json_response(scan_skills())
    except Exception as e:
        logger.error(f"Error listing skills: {e}")
        return web.Response(status=500, text=str(e))


@server.PromptServer.instance.routes.post("/rs_prompts/load_skill")
async def rs_prompts_load_skill(request):
    """加载单个 skill 完整数据（元数据 + 拼接内容 + 文件列表）。"""
    try:
        data = await request.json()
        skill_id = _normalize_skill_id(data.get("id", ""))
        d = _skill_dir(skill_id) if skill_id else None
        if not d:
            return web.Response(status=404, text="Skill not found")
        meta, _ = _read_skill_md(d)
        files = []
        for fn in _list_all_skill_files(d):
            fp = os.path.join(d, fn)
            files.append({"name": fn, "size": os.path.getsize(fp)})
        return web.json_response({
            "id": skill_id,
            "name": meta.get("name", skill_id),
            "source": _skill_source(d),
            "tags": meta.get("tags", []),
            "description": meta.get("description", ""),
            "inputs": meta.get("inputs") or ["text"],
            "category": meta.get("category", "image_enhance"),
            "content": load_skill_content(skill_id) or "",
            "files": files,
            "max_tokens": meta.get("max_tokens"),
            "multi_result": meta.get("multi_result"),
            "multi_turn": bool(meta.get("multi_turn", False)),
            "result_key": meta.get("result_key"),
            "gen_image": bool(meta.get("gen_image", False)),
        })
    except Exception as e:
        logger.error(f"Error loading skill: {e}")
        return web.Response(status=500, text=str(e))


@server.PromptServer.instance.routes.post("/rs_prompts/save_skill")
async def rs_prompts_save_skill(request):
    """保存/更新 skill 主文件（skill.md）。预设只读。"""
    try:
        data = await request.json()
        skill_id = _normalize_skill_id(data.get("id", ""))
        if not skill_id:
            return web.Response(status=400, text="Skill id required")
        source = data.get("source", "custom")
        existing_dir = _skill_dir(skill_id)
        if existing_dir and _skill_source(existing_dir) == "presets" and source != "presets":
            return web.Response(status=403, text="Cannot modify preset skill")
        final_name = (data.get("name") or "").strip() or skill_id
        conflict = _find_name_conflict(final_name, skill_id)
        if conflict:
            return web.Response(status=409, text=f"技能名称「{final_name}」已被 {conflict} 使用，请改用其他名称")
        ok = save_skill_main(
            skill_id,
            data.get("name", ""),
            data.get("content", ""),
            data.get("tags", []),
            source,
            data.get("multi_turn"),
            category=data.get("category"),
            gen_image=data.get("gen_image"),
            requires_ref=data.get("requires_ref"),
        )
        if not ok:
            return web.Response(status=500, text="Failed to save skill")
        return web.json_response({"success": True})
    except Exception as e:
        logger.error(f"Error saving skill: {e}")
        return web.Response(status=500, text=str(e))


@server.PromptServer.instance.routes.post("/rs_prompts/delete_skill")
async def rs_prompts_delete_skill(request):
    """删除整个 skill 目录（预设不可删）。"""
    try:
        data = await request.json()
        ok, msg = delete_skill(_normalize_skill_id(data.get("id", "")))
        if not ok and "preset" in msg.lower():
            return web.Response(status=403, text=msg)
        if not ok:
            return web.Response(status=404, text=msg)
        return web.json_response({"success": True})
    except Exception as e:
        logger.error(f"Error deleting skill: {e}")
        return web.Response(status=500, text=str(e))


@server.PromptServer.instance.routes.post("/rs_prompts/upload_skill")
async def rs_prompts_upload_skill(request):
    """上传 skill：.zip（file 字段）或目录清单（manifest + 有序 files 字段）。"""
    try:
        reader = await request.multipart()
        skill_id_field = ""
        manifest_raw = None
        zip_bytes = None
        file_parts = []
        async for part in reader:
            if part.name == "skill_id":
                skill_id_field = (await part.read()).decode("utf-8").strip()
            elif part.name == "manifest":
                manifest_raw = (await part.read()).decode("utf-8")
            elif part.name == "file" and part.filename:
                zip_bytes = await part.read()
            elif part.name == "files":
                file_parts.append((part.filename, await part.read()))

        with _skills_lock:
            if zip_bytes is not None:
                result = _upload_from_zip(zip_bytes, skill_id_field)
            elif manifest_raw is not None:
                try:
                    rel_paths = json.loads(manifest_raw)
                except Exception:
                    return web.Response(status=400, text="Invalid manifest JSON")
                result = _upload_from_manifest(rel_paths, file_parts, skill_id_field)
            else:
                return web.Response(status=400, text="No upload payload")

        if not result.get("success"):
            status = result.get("status", 500)
            return web.Response(status=status, text=result.get("message", "Upload failed"))
        return web.json_response(result)
    except Exception as e:
        logger.error(f"Error uploading skill: {e}")
        return web.Response(status=500, text=str(e))


@server.PromptServer.instance.routes.post("/rs_prompts/load_skill_file")
async def rs_prompts_load_skill_file(request):
    """加载 skill 目录内某个 .md 文件内容。"""
    try:
        data = await request.json()
        skill_id = _normalize_skill_id(data.get("id", ""))
        filename = data.get("file", "")
        d = _skill_dir(skill_id) if skill_id else None
        if not d:
            return web.Response(status=404, text="Skill not found")
        target = _safe_skill_file_path(d, filename)
        if not target or not os.path.isfile(target):
            return web.Response(status=404, text="File not found")
        with open(target, 'r', encoding='utf-8') as f:
            content = f.read()
        return web.json_response({"name": filename, "content": content})
    except Exception as e:
        logger.error(f"Error loading skill file: {e}")
        return web.Response(status=500, text=str(e))


@server.PromptServer.instance.routes.post("/rs_prompts/save_skill_file")
async def rs_prompts_save_skill_file(request):
    """保存 skill 目录内某个 .md 文件。"""
    try:
        data = await request.json()
        ok = save_skill_file(
            _normalize_skill_id(data.get("id", "")),
            data.get("file", ""),
            data.get("content", ""),
        )
        if not ok:
            return web.Response(status=400, text="Failed to save skill file")
        return web.json_response({"success": True})
    except Exception as e:
        logger.error(f"Error saving skill file: {e}")
        return web.Response(status=500, text=str(e))


@server.PromptServer.instance.routes.post("/rs_prompts/delete_skill_file")
async def rs_prompts_delete_skill_file(request):
    """删除 skill 目录内某个 .md 文件（skill.md 不可删）。"""
    try:
        data = await request.json()
        ok = delete_skill_file(
            _normalize_skill_id(data.get("id", "")),
            data.get("file", ""),
        )
        if not ok:
            return web.Response(status=400, text="Failed to delete skill file")
        return web.json_response({"success": True})
    except Exception as e:
        logger.error(f"Error deleting skill file: {e}")
        return web.Response(status=500, text=str(e))