import { app } from "../../../../scripts/app.js";
import { api } from "../../../../scripts/api.js";
import { $el } from "../../../../scripts/ui.js";
import { GalleryList } from './gallery-list.js';
import { GalleryCard } from './gallery-card.js';
import { GallerySetting } from './gallery-setting.js';
import { createRecipesPanel } from './recipes.js';
import {
    THUMBNAIL_SIZE_DEFAULT,
    THUMBNAIL_SIZE_MIN,
    THUMBNAIL_SIZE_MAX,
    THUMBNAIL_SIZE_STEP,
    getReservedSpace,
    getThumbnailSrc,
    getCoverHeight,
    showNoFilesMessage,
    showLoadingOverlay,
    showToast,
    showInlineFeedback
} from './gallery-utils.js';

// Load gallery CSS
const galleryCssLink = document.createElement('link');
galleryCssLink.rel = 'stylesheet';
galleryCssLink.href = "/extensions/ComfyUI-Neo-Nodes/gallery.css";
document.head.appendChild(galleryCssLink);

// Load recipes CSS
const recipesCssLink = document.createElement('link');
recipesCssLink.rel = 'stylesheet';
recipesCssLink.href = "/extensions/ComfyUI-Neo-Nodes/recipes.css";
document.head.appendChild(recipesCssLink);

// Civitai 收藏 view: bookmarked C-site models, shown like the Lora section.
const CIVITAI_DIR_NAME = "C站收藏";  // display label only (card name, breadcrumb) — never used for backend matching
const CIVITAI_DIR_KEY = "civitai_bookmarks";  // stable dir_name key sent to the backend (must match bookmark.CIVITAI_DIR_KEY)
const CIVITAI_VIEW_SOURCE = CIVITAI_DIR_KEY;  // same stable identifier reused in the URL state

/**
 * NeoGallery — preset-based gallery (no YAML).
 */
class NeoGallery {
    constructor(app) {
        this.app = app;
        this.maxThumbnailSize = THUMBNAIL_SIZE_DEFAULT;
        this.displayLabels = true;
        this.allDirectories = [];
        this.filteredDirectories = [];
        this.sortAscending = true;
        this._renderQueue = [];
        this._renderedCount = 0;
        this.isFocused = false;
        this.isVisible = false;
        
        // UI components
        this.list = new GalleryList(this);
        this.card = new GalleryCard(this);
        this.settings = new GallerySetting(this);
        this.searchInput = this.list.createSearchInput(this);
        this.thumbnailSizeSlider = this.list.createThumbnailSizeSlider(this);
        this.customDirSettingBtn = null;
        
        // Card-based layout state
        this.currentView = {
            mode: 'categories',
            source: null,
            categoryPath: [],
        };
        this.workflowMatchActive = false;   // smart filter: show only loras used in the workflow
        this._loraRefreshTimer = null;       // auto-refresh polling for the Lora section
        this.placeholderImageUrl = `${window.location.protocol}//${window.location.host}/neo_gallery/placeholder.png`;
        this.sectionStates = {};
        this.isSearchActive = false;
        this.elementId = "neo-gallery-panel-root";
        
        // Store current directory images for lightbox navigation (used in lazy mode)
        this._currentDirImages = [];
        
        // 滚动位置状态
        this._scrollPositions = {};
        this._currentScrollKey = null;
        
        
        // Custom dir input
        this.customDirInput = $el("input", {
            type: "text",
            value: "",
            readonly: true,
            className: "neo-gallery-custom-dir-input-inline",
            style: { display: "none" }
        });

        const customDirBtn = this.list.createCustomDirSettingBtn(this);

        // Main content area
        this.accordion = $el("div", { className: "neo-gallery-accordion" });

        this.element = $el("div", { id: this.elementId, className: "neo-gallery-panel" }, [
            $el("div", { 
                className: "neo-gallery-header-row",
                style: { display: 'grid', gridTemplateColumns: 'auto 1fr auto', alignItems: 'center' }
            }, [
                $el("h3", { 
                    className: "neo-gallery-header-title",
                    textContent: "Neo Gallery",
                    onclick: () => this.showCategoryCards(),
                    title: "Click to return to home"
                }),
                $el("div", { 
                    style: { display: 'flex', justifyContent: 'center', alignItems: 'center', gap: 10, gridColumn: '2' }
                }, [this.thumbnailSizeSlider]),
                $el("div", { style: { display: 'flex', gap: '12px', alignItems: 'center' } }, [customDirBtn])
            ]),
            $el("div", { className: "neo-gallery-search-row" }, [
                $el("div", { className: "neo-gallery-search-container" }, [this.searchInput])
            ]),
            $el("div", { 
                id: "neo-gallery-breadcrumb",
                className: "neo-gallery-breadcrumb",
                style: { display: 'none' }
            }, [this.list.createBreadcrumbHome(this)]),
            this.accordion,
            this.customDirInput
        ]);

        this.loadGallerySettings();
    }

    // ====== Directory Management ======

    async loadGallerySettings() {
        try {
            const resp = await api.fetchApi('/neo_gallery/get_settings');
            if (resp.ok) {
                const settings = await resp.json();
                const customDir = settings.custom_directory || "";
                this.customDirInput.value = customDir;
                
                if (this.customDirSettingBtn) {
                    if (customDir) {
                        const displayName = customDir.split(/[\\/]/).pop();
                        this.customDirSettingBtn.title = customDir + '\n(Click to change)\nCurrent: ' + displayName;
                        this.customDirSettingBtn.textContent = "\uD83D\uDCC1";
                    } else {
                        this.customDirSettingBtn.title = "Set custom directory\n(Currently not configured)";
                        this.customDirSettingBtn.textContent = "+";
                    }
                }
            }
        } catch (error) {
            console.error('Error loading gallery settings:', error);
            if (this.customDirSettingBtn) {
                this.customDirSettingBtn.title = "Failed to load settings";
                this.customDirSettingBtn.textContent = "?";
            }
        }
    }

    async promptAndSetCustomDir() {
        await this.settings.buildDirModal(this);
    }

    closeDirModal() {
        const modal = document.querySelector('.neo-gallery-dir-modal-overlay');
        if (modal) modal.remove();
    }

    async removeCustomDir(dirPath) {
    if (!confirm(`Remove directory "${dirPath}" from gallery?`)) return;

    const saveResp = await api.fetchApi('/neo_gallery/save_settings', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ action: "remove", path: dirPath })
    });
    const result = await saveResp.json();

    if (saveResp.ok && result.success) {
    // Clear thumbnails for this directory
    try {
            await api.fetchApi('/neo_gallery/clear_thumbnails', {
            method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ subfolder: dirPath })
                });
            } catch (e) {
                console.warn('[Neo Gallery] Failed to clear thumbnails:', e);
            }
            await this.loadGallery();
            await this.list.sortAndDisplayImages();
        } else {
            alert('Failed to remove directory: ' + (result.error || ''));
        }
    }

    // ====== State / Persistence ======

    async savePluginData(overrides) {
        const pluginData = {
            sectionStates: this.sectionStates,
            sortAscending: this.sortAscending,
            maxThumbnailSize: this.maxThumbnailSize,
            displayLabels: this.displayLabels,
            scrollPositions: this._scrollPositions,
            ...overrides
        };
        try {
            const resp = await api.fetchApi('/userdata/neo_gallery_data.json', {
                method: 'POST',
                body: JSON.stringify(pluginData),
                headers: { 'Content-Type': 'application/json' }
            });
        } catch (error) {
            console.error('Error saving plugin data:', error);
        }
    }

    async loadPluginData() {
        try {
            const response = await api.fetchApi('/userdata/neo_gallery_data.json');
            if (response.ok) {
                const data = await response.json();
                this.sectionStates = data.sectionStates || {};
                this.sortAscending = data.sortAscending !== undefined ? data.sortAscending : true;
                this.maxThumbnailSize = data.maxThumbnailSize || THUMBNAIL_SIZE_DEFAULT;
                this.displayLabels = data.displayLabels !== undefined ? data.displayLabels : true;
                this._scrollPositions = data.scrollPositions || {};
            }
        } catch (error) {
            console.error('Error loading plugin data:', error);
        }
    }

    // ====== Cover Image Cache ======

    // ====== Data Loading & Caching ======

    async loadGallery() {
        try {
            // Fetch directory structure with covers (covers loaded lazily per card via IntersectionObserver)
            const resp = await api.fetchApi('/neo_gallery/list?fields=dirs,covers');
            if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
            const data = await resp.json();
            
            this.allDirectories = (data.directories || []).map(dir => ({
                name: dir.name,
                path: dir.path,
                subdirs: dir.subdirs || {},
                read_only: dir.read_only || false,
                root_count: dir.root_count || 0,
                items: dir.items || [],
                source: dir.source || "local",
                lora_path: dir.lora_path || null,
                pending: dir.pending || false,
                civitai: dir.civitai || null,
                model_name: dir.model_name || "",
                base_model: dir.base_model || "",
                has_pending: dir.has_pending || false
            }));
            this.filteredDirectories = this.allDirectories;

            // Use covers from list response (no separate request needed)
            // FIX: Merge with existing cache instead of replacing to preserve covers when navigating back
            if (data.covers && Object.keys(data.covers).length > 0) {
                this._dirCovers = { ...this._dirCovers, ...data.covers };
                console.log('[Neo Gallery] Merged cover images from list response:', Object.keys(this._dirCovers).length, 'directories');
            }
        } catch (error) {
            console.error('Error loading gallery:', error);
            this.allDirectories = [];
            this.filteredDirectories = this.allDirectories;
        }
    }

    // ====== Smart Workflow Matching (智能感知) ======

    /**
     * Collect the lora paths currently loaded by LoraLoader nodes on the canvas.
     * Returns a Set of normalized (posix, forward-slash) lora relative paths.
     */
    collectUsedLoras() {
        const used = new Set();
        if (!this.app || !this.app.graph || !this.app.graph._nodes) return used;
        for (const node of this.app.graph._nodes) {
            if (node.mode === 4) continue; // bypassed nodes don't contribute
            if (!/^LoraLoader/i.test(node.comfyClass || '') || !node.widgets) continue;
            for (const w of node.widgets) {
                if (w.name === 'lora_name' && w.type === 'combo' && typeof w.value === 'string' && w.value) {
                    used.add(w.value.replace(/\\/g, '/'));
                }
            }
        }
        return used;
    }

    toggleWorkflowMatch() {
        this.workflowMatchActive = !this.workflowMatchActive;
        this.list.sortAndDisplayImages();
    }

    /**
     * Jump straight to the directory of a lora used by the current workflow.
     * The target card is briefly highlighted after render, but the rest of the
     * directory stays fully visible (no persistent filter).
     */
    async _jumpToUsedLora() {
        const used = [...this.collectUsedLoras()];
        if (used.length === 0) return;
        used.sort();
        this._jumpTargetPath = used[0];
        const segs = used[0].replace(/\.(safetensors|pt|ckpt|bin|sft)$/i, "").split("/");
        await this.showDirectoryStructure("Lora", segs.slice(0, -1));
    }

    // ====== Lora Section Auto-Refresh ======

    _isLoraView() {
        return this.currentView.mode === 'directory' && (this.currentView.source || '').toLowerCase().startsWith('lora');
    }

    startLoraRefresh() {
        if (this._loraRefreshTimer) return;
        this._loraRefreshTimer = setInterval(async () => {
            try {
                const resp = await api.fetchApi('/neo_gallery/lora_cache_status');
                if (!resp.ok) return;
                const st = await resp.json();
                // Keep refreshing while the auto-cache worker is active or loras are
                // queued with a configured API key; without a key there is nothing to fetch.
                if (this._isLoraView() && st.enabled && (st.running || st.pending_count > 0)) {
                    const src = this.currentView.source;
                    const segs = this.currentView.categoryPath || [];
                    await this.showDirectoryStructure(src, segs);
                } else {
                    this.stopLoraRefresh();
                }
            } catch (e) { /* keep polling */ }
        }, 2000);
    }

    stopLoraRefresh() {
        if (this._loraRefreshTimer) {
            clearInterval(this._loraRefreshTimer);
            this._loraRefreshTimer = null;
        }
    }

    // ====== 本地收藏（仅记录路径信息，打开时基于路径查找） ======

    _createLocalHomeCard() {
        const card = $el("div", {
            className: "neo-gallery-category-card neo-gallery-local-home",
            onclick: () => this.showLocalBookmarks()
        });
        const coverWrapper = $el("div", {
            className: "neo-gallery-card-cover-wrapper skeleton-loading",
            style: { minHeight: `${Math.max(this.maxThumbnailSize * 0.5, 80)}px`, maxHeight: `${Math.max(this.maxThumbnailSize, 80)}px` }
        });
        coverWrapper.appendChild($el("div", {
            className: "neo-gallery-card-cover neo-gallery-card-placeholder",
            textContent: "\uD83D\uDCCD"
        }));
        // 首页卡封面取收藏内容前两张（有收藏时异步补齐）。
        api.fetchApi('/neo_bookmark/local').then(r => (r.ok ? r.json() : { items: [] })).then(d => {
            const first = ((d && d.items) || []).find(i => i.covers && i.covers.length);
            if (first && card.isConnected) this._applyBookmarkCovers(coverWrapper, first.covers, first);
        }).catch(() => {});
        const typeBadge = $el("div", {
            className: "neo-gallery-card-type-badge type-directory",
            title: "本地收藏（记录路径，打开时基于路径查找）"
        }, ["\uD83D\uDCCD"]);
        const nameEl = $el("span", { className: "neo-gallery-card-name", textContent: "本地收藏" });
        const info = $el("div", { className: "neo-gallery-card-info" }, [nameEl]);
        card.appendChild(typeBadge);
        card.appendChild(coverWrapper);
        card.appendChild(info);
        return card;
    }

    async showLocalBookmarks() {
        await this.list._saveCurrentScrollPosition();
        this.currentView.mode = 'local_bookmarks';
        this.currentView.source = '本地收藏';
        this.currentView.categoryPath = [];
        this.stopLoraRefresh();
        this.list.updateBreadcrumb(this, [], '');

        const stateKey = 'gallery_v2:local_bookmarks:';
        const currentUrl = new URL(window.location.href);
        currentUrl.searchParams.set('gallery', stateKey);
        history.pushState({ galleryState: stateKey }, '', currentUrl.toString());

        await this._renderLocalBookmarks();
    }

    async _renderLocalBookmarks() {
        this.accordion.innerHTML = "";
        let data;
        try {
            const resp = await api.fetchApi('/neo_bookmark/local');
            data = await resp.json();
        } catch (e) {
            console.error('[Neo Gallery] Failed to load local bookmarks:', e);
            showNoFilesMessage(this.accordion, "加载本地收藏失败");
            return;
        }
        const items = (data && data.items) || [];
        if (items.length === 0) {
            showNoFilesMessage(this.accordion, "暂无本地收藏。在图片缩略图右下角的「⋯」按钮即可收藏。");
            return;
        }
        const container = $el("div", {
            className: "neo-gallery-category-grid",
            style: { gridTemplateColumns: `repeat(auto-fill, ${this.maxThumbnailSize}px)` }
        });
        for (const item of items) {
            container.appendChild(this._createLocalBookmarkCard(item));
        }
        this.accordion.appendChild(container);
    }

    // ====== Civitai 收藏 (bookmarked C-site models, shown like the Lora section) ======

    _createLocalBookmarkCard(item) {
        const card = $el("div", {
            className: "neo-gallery-category-card neo-gallery-local-card",
            onclick: () => this._openLocalBookmark(item)
        });
        card.dataset.bookmarkId = item.id;
        const coverWrapper = $el("div", {
            className: "neo-gallery-card-cover-wrapper skeleton-loading",
            style: { minHeight: `${Math.max(this.maxThumbnailSize * 0.5, 80)}px`, maxHeight: `${Math.max(this.maxThumbnailSize, 80)}px` }
        });
        card._coverWrapper = coverWrapper;
        this._applyBookmarkCovers(coverWrapper, item.covers || [], item);

        const sourceLabel = item.source === "oss" ? "OSS 预设" : (item.source === "civitai" ? "C 站" : "本地");
        const nameEl = $el("span", { className: "neo-gallery-card-name", textContent: item.name || item.filename || "未命名" });
        const info = $el("div", { className: "neo-gallery-card-info" }, [
            nameEl,
            $el("span", { className: "neo-gallery-card-source-badge", textContent: sourceLabel })
        ]);
        const isFile = !!item.filename;
        const typeBadge = $el("div", {
            className: `neo-gallery-card-type-badge ${isFile ? "type-image" : "type-directory"}`,
            title: `${sourceLabel}收藏 · ${[item.dir, item.subfolder, item.filename].filter(Boolean).join("/")}`
        }, [item.source === "oss" ? "\u2601\uFE0F" : (isFile ? "\uD83D\uDDBC\uFE0F" : "\uD83D\uDCCD")]);
        const delBtn = $el("div", {
            className: "neo-gallery-card-civitai-save-btn",
            title: "取消收藏",
            onclick: (e) => { e.stopPropagation(); this._removeLocalBookmark(item, card); }
        }, ["\u2716"]);

        card.appendChild(typeBadge);
        card.appendChild(coverWrapper);
        card.appendChild(info);
        card.appendChild(delBtn);
        return card;
    }

    async _openLocalBookmark(item) {
        try {
            if (item.source === "civitai") {
                await this.showDirectoryStructure(CIVITAI_DIR_KEY, [item.dir || item.filename]);
            } else if (item.filename) {
                // 单图收藏：仅显示本图，直接以灯箱打开该媒体（不进入目录）
                // 本地 subfolder 只是卡片内相对路径，需拼上顶层 dir 才能定位（与后端封面解析一致）
                const lbSub = item.source === "oss"
                    ? (item.dir || "")
                    : ((item.subfolder) ? `${item.dir}/${item.subfolder}` : (item.dir || ""));
                this.card.showLightbox(this, { filename: item.filename }, lbSub);
            } else {
                const segs = (item.subfolder || "").split("/").filter(Boolean);
                await this.showDirectoryStructure(item.dir, segs);
            }
        } catch (e) {
            console.error('[Neo Gallery] Failed to open local bookmark:', e);
            showToast(this.app, 'error', '打开收藏失败', '源路径可能已被移动或删除：' + String(e));
        }
    }

    async _removeLocalBookmark(item, card) {
        try {
            const resp = await api.fetchApi('/neo_bookmark/local/remove', {
                method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id: item.id })
            });
            const data = await resp.json();
            if (data.success) {
                if (card && card.parentNode) card.remove();
                showToast(this.app, 'success', '已取消收藏', item.name || '');
            } else {
                showToast(this.app, 'error', '取消收藏失败', data.error || '');
            }
        } catch (e) {
            showToast(this.app, 'error', '取消收藏失败', String(e));
        }
    }

    _createCivitaiHomeCard() {
        const card = $el("div", {
            className: "neo-gallery-category-card neo-gallery-civitai-home",
            onclick: () => this.showCivitaiBookmarks()
        });
        const coverWrapper = $el("div", {
            className: "neo-gallery-card-cover-wrapper skeleton-loading",
            style: { minHeight: `${Math.max(this.maxThumbnailSize * 0.5, 80)}px`, maxHeight: `${Math.max(this.maxThumbnailSize, 80)}px` }
        });
        coverWrapper.appendChild($el("div", {
            className: "neo-gallery-card-cover neo-gallery-card-placeholder",
            textContent: "\uD83D\uDCDA"
        }));
        // 首页卡封面取收藏列表内容前两张（开关开启且有收藏时异步补齐）。
        api.fetchApi('/neo_bookmark/civitai/list', {
            method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({})
        }).then(r => (r.ok ? r.json() : { success: false })).then(d => {
            const first = d && d.success ? ((d.items) || []).find(i => i.covers && i.covers.length) : null;
            if (first && card.isConnected) this._applyBookmarkCovers(coverWrapper, first.covers, first);
        }).catch(() => {});
        const typeBadge = $el("div", {
            className: "neo-gallery-card-type-badge type-directory",
            title: "C站收藏（可保存为配方）"
        }, ["\uD83D\uDCC1"]);
        const nameEl = $el("span", { className: "neo-gallery-card-name", textContent: CIVITAI_DIR_NAME });
        const info = $el("div", { className: "neo-gallery-card-info" }, [nameEl]);

        card.appendChild(typeBadge);
        card.appendChild(coverWrapper);
        card.appendChild(info);
        return card;
    }

    async showCivitaiBookmarks() {
        await this.list._saveCurrentScrollPosition();
        this.currentView.mode = 'civitai_bookmarks';
        this.currentView.source = CIVITAI_DIR_KEY;
        this.currentView.categoryPath = [];
        this.stopLoraRefresh();
        this.list.updateBreadcrumb(this, [], '');

        const stateKey = `gallery_v2:${encodeURIComponent(CIVITAI_VIEW_SOURCE)}:`;
        const currentUrl = new URL(window.location.href);
        currentUrl.searchParams.set('gallery', stateKey);
        history.pushState({ galleryState: stateKey }, '', currentUrl.toString());

        await this._renderCivitaiBookmarks();
    }

    async _renderCivitaiBookmarks(refresh = false, page = 0) {
        this.accordion.innerHTML = "";
        this._civitaiPage = page;
        let data;
        try {
            const resp = await api.fetchApi('/neo_bookmark/civitai/list', {
                method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ refresh, page })
            });
            data = await resp.json();
        } catch (e) {
            console.error('[Neo Gallery] Failed to load Civitai bookmarks:', e);
            showNoFilesMessage(this.accordion, "加载收藏失败");
            return;
        }

        if (!data.success) {
            const msg = data.needs_api_key ? "需在「Manage Directories」配置 C 站 API KEY" : (data.error || "加载收藏失败");
            showNoFilesMessage(this.accordion, msg);
            return;
        }

        const items = data.items || [];
        if (items.length === 0) {
            showNoFilesMessage(this.accordion, "暂无收藏的 C 站模型");
            return;
        }

        const refreshBtn = document.createElement("button");
        refreshBtn.textContent = "\u27F3 \u5237\u65B0";
        refreshBtn.title = "\u91CD\u65B0\u4ECE C \u7AD9\u62C9\u53D6\u6536\u85CF\u5217\u8868\uFF08\u5FFD\u7565\u7F13\u5B58\uFF09";
        refreshBtn.style.cssText = "margin:0 0 8px;padding:4px 12px;font-size:12px;cursor:pointer;background:#2a2a2a;color:#ccc;border:1px solid #444;border-radius:6px;";
        refreshBtn.onclick = async () => {
            if (refreshBtn.disabled) return;
            refreshBtn.disabled = true;
            refreshBtn.textContent = "\u27F3 \u5237\u65B0\u4E2D\u2026";
            try {
                await this._renderCivitaiBookmarks(true, this._civitaiPage);
            } catch (e) {
                console.error('[Neo Gallery] Failed to refresh Civitai bookmarks:', e);
                refreshBtn.disabled = false;
                refreshBtn.textContent = "\u27F3 \u5237\u65B0";
            }
        };

        const container = $el("div", {
            className: "neo-gallery-category-grid",
            style: { gridTemplateColumns: `repeat(auto-fill, ${this.maxThumbnailSize}px)` }
        });
        for (const item of items) {
            container.appendChild(this._createCivitaiBookmarkCard(item));
        }
        this.accordion.appendChild(refreshBtn);
        this.accordion.appendChild(container);

        // 上下页切换（与 Lora 板块一致的分页浏览）
        const pagination = $el("div", {
            className: "neo-gallery-pagination",
            style: { display: 'flex', justifyContent: 'center', alignItems: 'center', gap: '12px', marginTop: '12px' }
        }, [
            $el("button", {
                className: "neo-gallery-pagination-btn",
                title: "上一页",
                textContent: "‹ 上一页",
                disabled: page <= 0,
                onclick: () => this._renderCivitaiBookmarks(false, page - 1)
            }),
            $el("span", { className: "neo-gallery-pagination-info", textContent: `第 ${page + 1} 页` }),
            $el("button", {
                className: "neo-gallery-pagination-btn",
                title: "下一页",
                textContent: "下一页 ›",
                disabled: !data.has_more,
                onclick: () => this._renderCivitaiBookmarks(false, page + 1)
            })
        ]);
        this.accordion.appendChild(pagination);

        this._setupCivitaiCoverLazyLoad();
    }

    _createCivitaiBookmarkCard(item) {
        const card = $el("div", {
            className: "neo-gallery-category-card neo-gallery-civitai-card",
            onclick: (e) => this._openCivitaiBookmarkDir(item, e.currentTarget)
        });
        card.dataset.civitaiId = item.id;

        const coverWrapper = $el("div", {
            className: "neo-gallery-card-cover-wrapper skeleton-loading",
            style: { minHeight: `${Math.max(this.maxThumbnailSize * 0.5, 80)}px`, maxHeight: `${Math.max(this.maxThumbnailSize, 80)}px` }
        });

        const typeLabel = [item.type, item.baseModel].filter(Boolean).join(" · ");
        const nameEl = $el("span", { className: "neo-gallery-card-name", textContent: item.name || ("Civitai #" + item.id) });
        const info = $el("div", { className: "neo-gallery-card-info" }, [nameEl]);

        const typeBadge = $el("div", {
            className: "neo-gallery-card-type-badge type-directory",
            title: typeLabel || "Civitai 模型"
        }, ["\uD83D\uDCC1"]);

        const saveBtn = $el("div", {
            className: "neo-gallery-card-civitai-save-btn",
            title: "保存为配方",
            onclick: (e) => { e.stopPropagation(); this._saveCivitaiBookmarkAsRecipe(item, saveBtn); }
        }, ["\uD83D\uDCBE"]);

        card.appendChild(typeBadge);
        card.appendChild(coverWrapper);
        card.appendChild(info);
        card.appendChild(saveBtn);
        card._coverWrapper = coverWrapper;

        if (item.covers && item.covers.length) {
            this._applyBookmarkCovers(coverWrapper, item.covers, item);
        }
        return card;
    }

    async _openCivitaiBookmarkDir(item, card) {
        if (card && card.dataset.opening === "1") return;
        if (card) card.dataset.opening = "1";
        const progressEl = card ? $el("div", { className: "neo-gallery-civitai-progress", textContent: "正在连接 Civitai…" }) : null;
        if (progressEl) card.appendChild(progressEl);
        let pollTimer = null;
        const stopPolling = () => { if (pollTimer) { clearInterval(pollTimer); pollTimer = null; } };
        if (progressEl) {
            pollTimer = setInterval(async () => {
                try {
                    const resp = await api.fetchApi('/neo_bookmark/civitai/status');
                    const st = await resp.json();
                    if (st.running) {
                        progressEl.textContent = `正在缓存示例图 ${st.done}/${st.total} · ${st.current || ''}`;
                    } else if (st.error) {
                        progressEl.textContent = st.error;
                    }
                } catch (_) { /* keep the initial hint */ }
            }, 1000);
        }
        try {
            const resp = await api.fetchApi('/neo_bookmark/civitai/media', {
                method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id: item.id, name: item.name })
            });
            const data = await resp.json();
            if (!data.success) {
                showToast(this.app, 'error', '加载示例图失败', data.error || '');
                return;
            }
            if (!(data.images || []).length) {
                showToast(this.app, 'info', '无示例图', '该模型暂无可预览的示例图');
                return;
            }
            // 边下边开：下载到第一张即进入目录；剩余由后台任务续下，
            // 完成后自动刷新当前目录补齐（进度见卡片下方轮询提示）。
            const modelKey = data.model_key || String(item.id);
            await this.showDirectoryStructure(CIVITAI_DIR_KEY, [modelKey]);
            if (!data.complete) this._pollBookmarkMediaUntilDone(modelKey);
        } catch (e) {
            console.error('[Neo Gallery] Failed to open Civitai bookmark examples:', e);
            showToast(this.app, 'error', '打开失败', String(e));
        } finally {
            stopPolling();
            if (progressEl) progressEl.remove();
            if (card) delete card.dataset.opening;
        }
    }

    async _pollBookmarkMediaUntilDone(modelKey) {
        const started = Date.now();
        const timer = setInterval(async () => {
            try {
                const resp = await api.fetchApi('/neo_bookmark/civitai/status');
                const st = await resp.json();
                const sameDir = this.currentView.mode === 'directory' &&
                    (this.currentView.source || '') === CIVITAI_DIR_KEY &&
                    (this.currentView.categoryPath || []).join('/') === modelKey;
                if (!st.running) {
                    clearInterval(timer);
                    if (sameDir && !st.error) {
                        await this.showDirectoryStructure(CIVITAI_DIR_KEY, [modelKey]);
                    }
                } else if (!sameDir || Date.now() - started > 15 * 60 * 1000) {
                    clearInterval(timer);
                }
            } catch (_) { clearInterval(timer); }
        }, 2000);
    }

    _applyCivitaiCover(coverWrapper, url) {
        this._applyBookmarkCovers(coverWrapper, [{ url }], {});
    }

    /**
     * 收藏卡封面：从收藏内容取前两张渲染成双图网格。
     * covers 项形如 {filename, subfolder}（本地缓存，走缩略图接口）或 {url}（远程直链）。
     */
    _applyBookmarkCovers(coverWrapper, covers, item) {
        coverWrapper.classList.remove('skeleton-loading');
        coverWrapper.classList.add('skeleton-loaded');
        coverWrapper.innerHTML = '';
        const list = (covers || []).slice(0, 2);
        if (list.length === 0) {
            this._setCivitaiCoverPlaceholder(coverWrapper);
            return;
        }
        const coverGrid = $el("div", { className: "neo-gallery-card-cover-grid" });
        let loadedCount = 0;
        for (const c of list) {
            const itemEl = $el("div", { className: "neo-gallery-card-cover-grid-item" });
            const img = (c && c.url !== undefined && c.url !== null)
                ? $el("img", { src: c.url, alt: item.name || "", loading: "lazy" })
                : $el("img", { src: getThumbnailSrc(c, c.subfolder), alt: item.name || "", loading: "lazy" });
            img.onload = () => {
                loadedCount++;
                // 单图封面按真实宽高比撑高，contain 显示，避免裁切变形
                if (list.length === 1 && img.naturalWidth > 0) {
                    const cardWidth = coverWrapper.clientWidth || 160;
                    const maxCoverHeight = this.maxThumbnailSize - getReservedSpace(this.displayLabels);
                    const h = Math.round(Math.min(Math.max(cardWidth * img.naturalHeight / img.naturalWidth, 60), maxCoverHeight));
                    coverGrid.style.height = `${h}px`;
                    coverGrid.classList.add('aspect-fit');
                } else if (loadedCount === list.length) {
                    const h = getCoverHeight(coverWrapper, this);
                    coverGrid.style.height = `${h * list.length}px`;
                }
            };
            img.onerror = () => {
                loadedCount++;
                itemEl.innerHTML = '<div style="display:flex;align-items:center;justify-content:center;height:100%;color:#555;font-size:24px;">\uD83D\uDCDA</div>';
            };
            itemEl.appendChild(img);
            coverGrid.appendChild(itemEl);
        }
        coverWrapper.appendChild(coverGrid);
    }

    _setCivitaiCoverPlaceholder(coverWrapper) {
        coverWrapper.classList.remove('skeleton-loading');
        coverWrapper.innerHTML = '';
        coverWrapper.appendChild($el("div", {
            className: "neo-gallery-card-cover neo-gallery-card-placeholder",
            textContent: "\uD83D\uDCDA"
        }));
    }

    _setupCivitaiCoverLazyLoad() {
        // Fetch covers for cards that didn't get one from the list response (like Lora lazy covers).
        const pending = Array.from(this.accordion.querySelectorAll('.neo-gallery-civitai-card[data-civitai-id]'))
            .filter(c => c._coverWrapper && c._coverWrapper.classList.contains('skeleton-loading'));
        if (pending.length === 0) return;

        const observer = new IntersectionObserver(async (entries, obs) => {
            for (const entry of entries) {
                if (!entry.isIntersecting) continue;
                const card = entry.target;
                obs.unobserve(card);
                try {
                    const resp = await api.fetchApi('/neo_bookmark/civitai/cover', {
                        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id: card.dataset.civitaiId })
                    });
                    const data = await resp.json();
                    if (data.success && data.cover) {
                        this._applyCivitaiCover(card._coverWrapper, data.cover);
                    } else {
                        this._setCivitaiCoverPlaceholder(card._coverWrapper);
                    }
                } catch (e) {
                    this._setCivitaiCoverPlaceholder(card._coverWrapper);
                }
            }
        }, { rootMargin: '200px' });

        for (const card of pending) observer.observe(card);
    }

    async _saveCivitaiBookmarkAsRecipe(item, button) {
        if (button.dataset.saving === "1") return;
        const url = `https://civitai.com/models/${item.id}`;
        button.dataset.saving = "1";
        button.textContent = "\u23F3";
        try {
            const resolveResp = await api.fetchApi('/neo_bookmark/civitai/resolve', {
                method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ url })
            });
            const resolved = await resolveResp.json();
            if (!resolved.success) {
                showInlineFeedback(button, resolved.error || "解析失败", "error");
                button.textContent = "\uD83D\uDCBE";
                return;
            }
            const saveResp = await api.fetchApi('/rs_recipes/save_from_civitai', {
                method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({
                    name: resolved.name || item.name,
                    model_id: resolved.model_id,
                    prompt: resolved.prompt || "",
                    images: resolved.images || [],
                    loras: resolved.loras || []
                })
            });
            const saved = await saveResp.json();
            if (!saved.success) {
                showInlineFeedback(button, saved.error || "保存失败", "error");
                button.textContent = "\uD83D\uDCBE";
                return;
            }
            showInlineFeedback(button, "已保存为配方", "success");
            button.textContent = "\u2705";
        } catch (e) {
            console.error('[Neo Gallery] Failed to save Civitai recipe:', e);
            showInlineFeedback(button, String(e), "error");
            button.textContent = "\uD83D\uDCBE";
        } finally {
            button.dataset.saving = "";
        }
    }

    async showDirectoryStructure(source, pathSegments = []) {
        const dirName = source;
        const relPath = pathSegments.join("/");

        // The civitai_bookmarks top level is a custom bookmark list, not a real directory.
        // With no path segments we show that list; with path segments we render the
        // selected model's cached example images as a standard directory (like Lora).
        if (dirName === CIVITAI_DIR_KEY && pathSegments.length === 0) {
            this.showCivitaiBookmarks();
            return;
        }

        // 修复：在进入新视图之前，先保存当前视图的滚动位置
        if (this.currentView.mode !== 'directory' || this.currentView.source !== dirName) {
            await this.list._saveCurrentScrollPosition();
        }
        
        try {
            // Use /neo_gallery/list with fields=dirs,items,covers to get directory structure, items, and covers
            const resp = await api.fetchApi(`/neo_gallery/list?fields=dirs,items,covers&dir_name=${encodeURIComponent(dirName)}&path=${encodeURIComponent(relPath)}`);
            if (resp.status === 404) {
                // 目录已不存在（被删除/移动，或 URL 里残留的旧导航状态）：回到首页而不是报错。
                this.currentView.mode = 'categories';
                await this.showCategoryCards();
                return;
            }
            if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
            
            const data = await resp.json();
            let structure = data.directories[0] || {};
            
            // Update covers cache if provided (merge to preserve parent dir covers when navigating back)
            if (data.covers && Object.keys(data.covers).length > 0) {
                this._dirCovers = { ...this._dirCovers, ...data.covers };
                console.log('[Neo Gallery] Merged cover images from directory response:', Object.keys(this._dirCovers).length, 'directories');
            }
            
            this.currentView.mode = 'directory';
            this.currentView.source = dirName;
            this.currentView.categoryPath = pathSegments;
            this._currentDirStructure = structure;

            this.list.updateBreadcrumb(this, pathSegments, '');

            this.list.renderDirectoryStructure(structure, dirName, pathSegments);

            // Auto-refresh while browsing the Lora section so newly cached examples appear.
            if (String(dirName).toLowerCase().startsWith('lora')) {
                this.startLoraRefresh();
            } else {
                this.stopLoraRefresh();
            }
            
            // Push state to history for back button support (use query param to avoid conflict with workflow hash)
            const stateKey = `gallery_v2:${encodeURIComponent(dirName)}:${pathSegments.join('/')}`;
            const currentUrl = new URL(window.location.href);
            currentUrl.searchParams.set('gallery', stateKey);
            history.pushState({ galleryState: stateKey }, '', currentUrl.toString());

        } catch (error) {
            console.error('[Gallery] Error loading directory structure:', error);
            showToast(this.app, 'error', 'Error', 'Failed to load directory structure');
        }
    }

    showCategoryImages(source, pathSegments, displayName) {
        this.showDirectoryStructure(source, pathSegments || []);
    }

    async showCategoryCards() {
        // 保存当前滚动位置（在切换 mode 之前）
        const currentKey = this.list._getScrollKey();
        if (currentKey) {
            const scrollContainer = this.list._getScrollContainer();
            const scrollTop = scrollContainer === window 
                ? window.pageYOffset || document.documentElement.scrollTop 
                : scrollContainer.scrollTop;
            this._scrollPositions[currentKey] = scrollTop;
        }
        
        this.currentView.mode = 'categories';
        this.currentView.source = null;
        this.currentView.categoryPath = [];
        this.stopLoraRefresh();

        const breadcrumb = document.getElementById("neo-gallery-breadcrumb");
        if (breadcrumb) {
            breadcrumb.style.display = 'none';
        }

        // Remove gallery query param when going back to categories
        const currentUrl = new URL(window.location.href);
        currentUrl.searchParams.delete('gallery');
        history.replaceState(null, '', currentUrl.toString());

        await this.list.sortAndDisplayImages();
    }

    // ====== Actions ======

    async deleteItem(name, subfolder) {
        try {
            const response = await api.fetchApi('/neo_gallery/delete', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ filename: name, subfolder })
            });
            const result = await response.json();
            
            // Check success field (new format) or deleted field (legacy fallback)
            if (result.success || result.deleted) {
                showToast(this.app, 'success', 'Deleted', `Removed: ${name}`);
                
                // Remove from data source immediately
                // In lazy mode, use _currentDirImages as fallback since dir.items is undefined
                for (const dir of this.allDirectories) {
                    const items = Array.isArray(dir.items) ? dir.items : [];
                    if (items.length > 0) {
                        const before = items.length;
                        dir.items = items.filter(item => item.name !== name || item.subfolder !== subfolder);
                        if (before !== dir.items.length) break;
                    }
                }
                
                // Also remove from filtered directories (search results)
                for (const dir of this.filteredDirectories) {
                    const items = Array.isArray(dir.items) ? dir.items : [];
                    if (items.length > 0) {
                        const before = items.length;
                        dir.items = items.filter(item => item.name !== name || item.subfolder !== subfolder);
                        if (before !== dir.items.length) break;
                    }
                }
                
                // Also remove from _currentDirImages (lazy mode fallback)
                if (this._currentDirImages && this._currentDirImages.length > 0) {
                    const before = this._currentDirImages.length;
                    this._currentDirImages = this._currentDirImages.filter(item => item.name !== name || item.subfolder !== subfolder);
                    if (before !== this._currentDirImages.length) {
                        // Re-render current view to reflect deletion
                        await this.list.sortAndDisplayImages();
                    }
                }
                
                // Remove DOM element immediately for better UX
                let domRemoved = false;
                
                // Try matching by filename (with extension) and also try without extension
                const nameWithoutExt = name.replace(/\.(png|jpg|jpeg|gif|webp|bmp|tiff|mp4|webm|mov|avi|mkv|flv|wmv)$/i, '');
                
                // First try: match with full filename (image.filename in DOM) or without extension
                const thumbContainers = document.querySelectorAll('.neo-gallery-thumb-container');
                for (const container of thumbContainers) {
                    if ((container.dataset.filename === name || container.dataset.filename === nameWithoutExt) && 
                        container.dataset.subfolder === subfolder) {
                        container.remove();
                        domRemoved = true;
                        break;
                    }
                }
                
                // Second try: match by checking if filename starts with the deleted name (handles extension mismatch)
                if (!domRemoved) {
                    for (const container of thumbContainers) {
                        const containerName = container.dataset.filename || '';
                        const containerSubfolder = container.dataset.subfolder || '';
                        if ((containerName === name || containerName.startsWith(nameWithoutExt + '.')) && 
                            containerSubfolder === subfolder) {
                            container.remove();
                            domRemoved = true;
                            break;
                        }
                    }
                }
                
                // Also remove from presets directory cards that might reference this file
                if (!domRemoved) {
                    const cardThumbnails = document.querySelectorAll('.neo-gallery-card-cover-grid-item img');
                    for (const img of cardThumbnails) {
                        if (img.alt === name || (img.src && img.src.includes(encodeURIComponent(name)))) {
                            img.parentElement?.parentElement?.remove();
                            break;
                        }
                    }
                }
                
                // If no elements remain, show empty state
                const remaining = document.querySelectorAll('.neo-gallery-thumb-container');
                if (remaining.length === 0 && !this.isSearchActive) {
                    this.displayNoFilesMessage();
                }
            } else {
                const errorMsg = result.error || 'Unknown error';
                showToast(this.app, 'error', 'Delete Failed', errorMsg);
            }
        } catch (error) {
            console.error("Error deleting item:", error);
            showToast(this.app, 'error', 'Delete Failed', error.message || 'Network error');
        }
    }

    async handleSearch(searchTerm) {
        searchTerm = searchTerm.toLowerCase();
        this.isSearchActive = searchTerm.length > 0;
        
        // Use list?search_mode=1 to get lightweight searchable data (style + content only, no full txt parsing)
        const resp = await api.fetchApi('/neo_gallery/list?search_mode=1');
        if (!resp.ok) {
            console.error('[Gallery] Search failed: could not fetch search data');
            this.filteredDirectories = [];
            await this.list.sortAndDisplayImages();
            return;
        }
        
        const data = await resp.json();
        this.filteredDirectories = (data.directories || [])
            .map(dir => ({
                ...dir,
                items: (dir.items || []).filter(img =>
                    (img.name && img.name.toLowerCase().includes(searchTerm)) ||
                    (img.style && img.style.toLowerCase().includes(searchTerm)) ||
                    (img.content && img.content.toLowerCase().includes(searchTerm))
                )
            }))
            .filter(d => d.items.length > 0);
        
        this.currentView.mode = 'categories';
        this.currentView.source = null;
        this.currentView.categoryPath = [];
        
        await this.list.sortAndDisplayImages();
    }

    async updateThumbnailSize(newSize) {
        this.maxThumbnailSize = newSize;
        if (this.thumbnailSizeSlider) {
            const slider = this.thumbnailSizeSlider.querySelector("input[type='range']");
            if (slider) slider.value = newSize;
        }
        const grids = document.querySelectorAll('.neo-gallery-category-grid');
        for (const grid of grids) {
            if (grid.offsetParent !== null) {
                grid.style.gridTemplateColumns = `repeat(auto-fill, ${newSize}px)`;
            }
        }
        await this.list.sortAndDisplayImages();
    }

    async updateLabelDisplay(display) {
        this.displayLabels = display;
        await this.list.sortAndDisplayImages();
    }

    // ====== Prompt Handling ======

    cleanText(text) {
        if (!text) return "";
        text = text.replace(/^[,\s]+|[,\s]+$/g, '');
        text = text.replace(/\s*BREAK\s*(?:,\s*)?/gi, '. ');
        text = text.replace(/\.{2,}/g, '.').replace(/,\s*\./g, '.');
        text = text.replace(/([.,])(?=\S)/g, '$1 ').trim();
        return text;
    }

    getFirstSegment(text) {
        if (!text) return "";
        const segments = text.split(/[.\u3002\uFF01\uFF01\uff1b:\n]+/).filter(s => s.trim());
        if (segments.length === 0) return "";
        let first = segments[0].trim();
        const colonIdx = first.indexOf('\uff1a');
        if (colonIdx > 0) {
            first = first.substring(colonIdx + 1).trim();
        }
        return first.length > 50 ? first.substring(0, 50) + '...' : first;
    }

    parsePromptSections(txtContent) {
        if (!txtContent) return [];
        const rawSegments = txtContent.split(/[.\u3002\uff01\uff01\uff1b\n]+/).filter(s => s.trim());
        const sections = [];

        for (const rawSeg of rawSegments) {
            const trimmed = rawSeg.trim();
            if (!trimmed) continue;

            const fullColonMatch = trimmed.match(/^(.+?)[\uff1a](.*)$/s);
            if (fullColonMatch) {
                const beforeColon = fullColonMatch[1].trim();
                const afterColon = fullColonMatch[2].trim();
                const cjkMatch = beforeColon.match(/[\u4e00-\u9fa5]/g);
                const cjkCount = cjkMatch ? cjkMatch.length : 0;

                if (cjkCount > 0 && cjkCount <= 10 && beforeColon.length <= 30) {
                    sections.push({ label: beforeColon, value: afterColon });
                } else {
                    sections.push({ label: null, value: trimmed });
                }
                continue;
            }

            sections.push({ label: null, value: trimmed });
        }

        return sections;
    }

    combineTexts(existing, newText) {
        existing = this.cleanText(existing);
        newText = this.cleanText(newText);
        if (!existing) return newText;
        return existing.endsWith('.') ? existing + ' ' + newText : existing + ', ' + newText;
    }

    // ====== Utility ======

    debounce(func, wait) {
        let timeout;
        return function(...args) {
            clearTimeout(timeout);
            timeout = setTimeout(() => func(...args), wait);
        };
    }

    showToast(severity, summary, detail) {
        showToast(this.app, severity, summary, detail);
    }

    showInlineFeedback(button, message, type) {
        showInlineFeedback(button, message, type);
    }

    displayNoFilesMessage() {
        this.accordion.appendChild($el("div", {
            className: "neo-gallery-no-files-message"
        }, [
            $el("div", { className: "neo-gallery-no-files-message-icon", textContent: "\uD83D\uDCF7" }),
            $el("p", { className: "neo-gallery-no-files-message-text", textContent: "No presets found. Add images + .txt files to gallery/presets/ or click \u{1F4C1} to add custom directories." })
        ]));
    }

    // ====== Image Send ======

    async sendImageToNode(image, target, button) {
        const selectedValue = target === 'selected' ? 'selected' : target;
        let targetNode = null;
        let targetWidget = null;
        if (selectedValue === 'selected') {
            const selKeys = Object.keys(app.canvas.selected_nodes);
            if (selKeys.length > 0) {
                targetNode = app.canvas.selected_nodes[selKeys[0]];
                targetWidget = targetNode?.widgets?.find(w => /image|upload/.test((w.name||'').toLowerCase()));
            }
        } else {
            const [nodeId, , index] = selectedValue.split(':');
            targetNode = app.graph.getNodeById(parseInt(nodeId));
            targetWidget = targetNode?.widgets?.[parseInt(index)];
        }
        if (!targetNode || !targetWidget) {
            showToast(this.app, 'error', 'Send Failed', 'Could not find target node/widget.');
            return;
        }
        const widgetType = targetWidget.type || '';
        
        if (widgetType === 'combo') {
            try {
                const resp = await api.fetchApi('/neo_gallery/copy_to_input?filename=' + encodeURIComponent(image.filename) + (image.subfolder ? '&subfolder=' + encodeURIComponent(image.subfolder) : ''));
                if (resp.ok) {
                    const result = await resp.json();
                    if (result.success) {
                        targetWidget.value = result.skipped ? image.filename : result.filename;
                    } else {
                        showToast(this.app, 'error', 'Copy Failed', result.error || 'Failed to copy image to input directory');
                        return;
                    }
                } else {
                    showToast(this.app, 'error', 'Copy Failed', 'Failed to copy image');
                    return;
                }
            } catch (e) {
                console.error('[Gallery] Error copying image:', e);
                showToast(this.app, 'error', 'Copy Failed', 'Error copying image');
                return;
            }
        } else {
            const filePath = `${image.subfolder || ''}/${image.filename}`;
            if (widgetType === 'customtext' || widgetType === 'text') {
                targetWidget.value = filePath;
            } else {
                targetWidget.value = {
                    filename: image.filename,
                    subfolder: image.subfolder || '',
                    type: image.type || 'input'
                };
            }
        }
        if (widgetType === 'combo' && targetWidget.callback) {
            targetWidget.callback(targetWidget.value);
        } else if (targetNode.onWidgetChanged) {
            targetNode.onWidgetChanged(targetWidget.name, targetWidget.value);
        }
        app.graph.setDirtyCanvas(true, true);
        showInlineFeedback(button, '\u2705 Image Sent!', 'success');
        showToast(this.app, 'success', 'Image Sent!', `Sent to ${targetNode.title || 'Node'} - ${targetWidget.name}`);
    }

    // ====== Video Send ======

    async sendVideoToNode(image, target, button) {
        const selectedValue = target === 'selected' ? 'selected' : target;
        let targetNode = null;
        let targetWidget = null;
        if (selectedValue === 'selected') {
            const selKeys = Object.keys(app.canvas.selected_nodes);
            if (selKeys.length > 0) {
                targetNode = app.canvas.selected_nodes[selKeys[0]];
                targetWidget = targetNode?.widgets?.find(w => /video/.test((w.name||'').toLowerCase()));
            }
        } else {
            const [nodeId, , index] = selectedValue.split(':');
            targetNode = app.graph.getNodeById(parseInt(nodeId));
            targetWidget = targetNode?.widgets?.[parseInt(index)];
        }
        if (!targetNode || !targetWidget) {
            showToast(this.app, 'error', 'Send Failed', 'Could not find target node/widget.');
            return;
        }
        const widgetType = targetWidget.type || '';
        
        if (widgetType === 'combo') {
            try {
                const resp = await api.fetchApi('/neo_gallery/copy_to_input?filename=' + encodeURIComponent(image.filename) + (image.subfolder ? '&subfolder=' + encodeURIComponent(image.subfolder) : ''));
                if (resp.ok) {
                    const result = await resp.json();
                    if (result.success) {
                        targetWidget.value = result.skipped ? image.filename : result.filename;
                    } else {
                        showToast(this.app, 'error', 'Copy Failed', result.error || 'Failed to copy video to input directory');
                        return;
                    }
                } else {
                    showToast(this.app, 'error', 'Copy Failed', 'Failed to copy video');
                    return;
                }
            } catch (e) {
                console.error('[Gallery] Error copying video:', e);
                showToast(this.app, 'error', 'Copy Failed', 'Error copying video');
                return;
            }
        } else {
            const filePath = `${image.subfolder || ''}/${image.filename}`;
            if (widgetType === 'customtext' || widgetType === 'text') {
                targetWidget.value = filePath;
            } else {
                targetWidget.value = {
                    filename: image.filename,
                    subfolder: image.subfolder || '',
                    type: image.type || 'input'
                };
            }
        }
        if (widgetType === 'combo' && targetWidget.callback) {
            targetWidget.callback(targetWidget.value);
        } else if (targetNode.onWidgetChanged) {
            targetNode.onWidgetChanged(targetWidget.name, targetWidget.value);
        }
        app.graph.setDirtyCanvas(true, true);
        showInlineFeedback(button, '\u2705 Video Sent!', 'success');
        showToast(this.app, 'success', 'Video Sent!', `Sent to ${targetNode.title || 'Node'} - ${targetWidget.name}`);
    }

    // ====== Send Menus ======

    async sendLoraToNode(loraPath, target, button) {
        let targetNode = null;
        let targetWidget = null;
        if (target === 'selected') {
            const selKeys = Object.keys(app.canvas.selected_nodes);
            if (selKeys.length > 0) {
                targetNode = app.canvas.selected_nodes[selKeys[0]];
                targetWidget = targetNode?.widgets?.find(w => w.name === 'lora_name');
            }
        } else {
            const [nodeId, , index] = target.split(':');
            targetNode = app.graph.getNodeById(parseInt(nodeId));
            targetWidget = targetNode?.widgets?.[parseInt(index)];
        }
        if (!targetNode || !targetWidget) {
            showToast(this.app, 'error', 'Send Failed', 'Could not find target node/widget.');
            return;
        }
        // LoraLoader combo values use OS separators; lora_path from the gallery is posix.
        const normalized = loraPath.replace(/\//g, '\\');
        const options = targetWidget.options || (targetWidget.options_values || []);
        const matched = Array.isArray(options) ? options.find(o => (o || '').replace(/\\/g, '/') === loraPath.replace(/\\/g, '/')) : null;
        targetWidget.value = matched !== undefined && matched !== null ? matched : normalized;
        if (targetWidget.callback) {
            targetWidget.callback(targetWidget.value);
        } else if (targetNode.onWidgetChanged) {
            targetNode.onWidgetChanged(targetWidget.name, targetWidget.value);
        }
        app.graph.setDirtyCanvas(true, true);
        showInlineFeedback(button, '\u2705 Lora Sent!', 'success');
        showToast(this.app, 'success', 'Lora Sent!', `${targetWidget.value} \u2192 ${targetNode.title || 'Node'}`);
    }

    // ====== Main init ======

    async init() {
        await this.loadPluginData();
        
        // Restore gallery state from URL query param on page load
        const params = new URLSearchParams(window.location.search);
        const galleryParam = params.get('gallery');
        if (galleryParam) {
            let dirName, pathSegments;
            const v2Match = galleryParam.match(/^gallery_v2:(.+):(.*)$/);
            if (v2Match) {
                dirName = decodeURIComponent(v2Match[1]);
                const pathStr = v2Match[2];
                pathSegments = pathStr ? pathStr.split('/') : [];
            } else {
                const match = galleryParam.match(/^gallery_(.+?)_(.*)$/);
                if (match) {
                    dirName = match[1];
                    const pathStr = match[2];
                    pathSegments = pathStr ? pathStr.split('/') : [];
                }
            }
            if (dirName) {
                this.currentView.mode = 'directory';
                this.currentView.source = dirName;
                this.currentView.categoryPath = pathSegments;
                // Load gallery data first so breadcrumb can initialize properly
                await this.loadGallery();
                await this.showDirectoryStructure(dirName, pathSegments);
                return; // skip normal init
            }
        }

        // Intercept browser back button when gallery is visible
        window.addEventListener('popstate', (e) => {
            if (!this.isVisible) return;
            if (document.activeElement?.tagName === 'INPUT' || document.activeElement?.tagName === 'TEXTAREA') return;
            if (this.currentView.mode === 'directory' && this.currentView.categoryPath.length > 0) {
                const parentPath = this.currentView.categoryPath.slice(0, -1);
                this.showDirectoryStructure(this.currentView.source, parentPath);
            } else {
                this.showCategoryCards();
            }
        });

        // Intercept keyboard back navigation (Alt+Left, Backspace) - use capture to beat ComfyUI
        window.addEventListener('keydown', (e) => {
            if (!this.isVisible) return;
            if (document.activeElement?.tagName === 'INPUT' || document.activeElement?.tagName === 'TEXTAREA') return;
            
            if ((e.altKey && e.key === 'ArrowLeft') || (e.ctrlKey && e.key === 'ArrowLeft')) {
                e.preventDefault();
                e.stopPropagation();
                if (this.currentView.mode === 'directory' && this.currentView.categoryPath.length > 0) {
                    const parentPath = this.currentView.categoryPath.slice(0, -1);
                    this.showDirectoryStructure(this.currentView.source, parentPath);
                } else {
                    this.showCategoryCards();
                }
            } else if (e.key === 'Backspace') {
                e.preventDefault();
                e.stopPropagation();
                if (this.currentView.mode === 'directory' && this.currentView.categoryPath.length > 0) {
                    const parentPath = this.currentView.categoryPath.slice(0, -1);
                    this.showDirectoryStructure(this.currentView.source, parentPath);
                } else {
                    this.showCategoryCards();
                }
            }
        }, true);
    }

    async loadAndDisplay() {
        this.accordion.innerHTML = '';
        const loadingEl = showLoadingOverlay(this.accordion, this.maxThumbnailSize);
        
        // 直接加载（不额外增加延迟）
        await this.loadGallery();
        await this.list.sortAndDisplayImages();
        
        if (loadingEl.parentNode) loadingEl.remove();
    }

    /**
     * 启动滚动监听器，在每次滚动时自动保存当前位置
     */
    startScrollListener() {
        // 清除旧的监听器
        this.stopScrollListener();
        
        const onScroll = () => {
            if (!this.currentView || !this.currentView.mode) return;
            
            const key = this.list._getScrollKey();
            if (!key) return;
            
            const scrollContainer = this.list._getScrollContainer();
            let scrollTop = 0;
            if (scrollContainer === window) {
                scrollTop = window.pageYOffset || document.documentElement.scrollTop;
            } else {
                scrollTop = scrollContainer.scrollTop;
            }
            
            // 只在位置变化超过 50px 时保存，避免频繁写入
            const prevValue = this._scrollPositions[key];
            if (prevValue === undefined || Math.abs(scrollTop - prevValue) > 50) {
                this._scrollPositions[key] = scrollTop;
            }
        };
        
        // 监听滚动容器的 scroll 事件
        const scrollContainer = this.list._getScrollContainer();
        if (scrollContainer === window) {
            window.addEventListener('scroll', onScroll, { passive: true });
            this._scrollListener = onScroll;
            this._scrollTarget = window;
        } else {
            scrollContainer.addEventListener('scroll', onScroll, { passive: true });
            this._scrollListener = onScroll;
            this._scrollTarget = scrollContainer;
        }
    }

    stopScrollListener() {
        if (this._scrollListener && this._scrollTarget) {
            this._scrollTarget.removeEventListener('scroll', this._scrollListener);
            this._scrollListener = null;
            this._scrollTarget = null;
        }
    }

}

// ====== Extension Registration =====
app.registerExtension({
    name: "comfy.neo.gallery",
    async setup() {
        const gallery = new NeoGallery(app);
        app.neoGallery = gallery;
        await gallery.init();

        app.ui.settings.addSetting({
            id: "Neo Gallery._General.maxThumbnailSize",
            name: "Neo Gallery Max Thumbnail Size",
            type: "slider", attrs: { min: THUMBNAIL_SIZE_MIN, max: THUMBNAIL_SIZE_MAX, step: THUMBNAIL_SIZE_STEP }, defaultValue: THUMBNAIL_SIZE_DEFAULT,
            onChange: (val) => { if (app.neoGallery) app.neoGallery.updateThumbnailSize(val); }
        });

        app.ui.settings.addSetting({
            id: "Neo Gallery._General.displayLabels",
            name: "Neo Gallery Display Image Labels",
            type: "boolean", defaultValue: true,
            onChange: (val) => { if (app.neoGallery) app.neoGallery.updateLabelDisplay(val); }
        });

        // Periodic persistence of scroll positions (every 5 seconds when gallery is visible)
        let _scrollPersistInterval = null;
        
        if (app.extensionManager && app.extensionManager.registerSidebarTab) {
                app.extensionManager.registerSidebarTab({
            id: "neo.gallery",
            icon: "pi pi-images",
            title: "素材",
            tooltip: "Neo Gallery",
            type: "custom",
            render: async (el) => {
                el.innerHTML = "";
                
                if (gallery.element.parentNode) {
                    gallery.element.parentNode.removeChild(gallery.element);
                }
                el.appendChild(gallery.element);
                
                if (!gallery._loaded) {
                    await gallery.loadAndDisplay();
                    gallery._loaded = true;
                } else {
                    gallery.accordion.innerHTML = "";
                    await gallery.list.sortAndDisplayImages();
                }
                // Re-initialize breadcrumb if URL has gallery param (panel was mounted after init)
                const params = new URLSearchParams(window.location.search);
                const galleryParam = params.get('gallery');
                if (galleryParam && gallery.currentView.mode === 'directory') {
                    gallery.list.updateBreadcrumb(gallery, gallery.currentView.categoryPath, '');
                }
                gallery.isVisible = true;
                
                // 启动滚动监听器，在每次滚动时自动保存位置
                gallery.startScrollListener();

            },
            });

            // 视频配方侧边栏
            app.extensionManager.registerSidebarTab({
                id: "neo.recipes",
                icon: "pi pi-box",
                title: "配方",
                tooltip: "Neo Recipes (视频配方)",
                type: "custom",
                render: async (el) => {
                    el.innerHTML = "";
                    const panel = await createRecipesPanel();
                    el.appendChild(panel);
                },
            });

        }
    },
});
